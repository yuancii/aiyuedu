package io.legado.app.ui.book.read

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.view.menu.MenuItemImpl
import androidx.core.view.doOnLayout
import androidx.core.view.get
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.core.view.size
import androidx.lifecycle.lifecycleScope
import com.jaredrummler.android.colorpicker.ColorPickerDialog
import com.jaredrummler.android.colorpicker.ColorPickerDialogListener
import io.legado.app.BuildConfig
import io.legado.app.R
import io.legado.app.constant.AppConst
import io.legado.app.constant.AppLog
import io.legado.app.constant.BookType
import io.legado.app.constant.EventBus
import io.legado.app.constant.PreferKey
import io.legado.app.constant.Status
import io.legado.app.data.appDb
import io.legado.app.data.entities.BaseSource
import io.legado.app.data.entities.Book
import io.legado.app.data.entities.replaceBookAfterSourceChange
import io.legado.app.data.entities.BookChapter
import io.legado.app.data.entities.BookHighlight
import io.legado.app.data.entities.BookProgress
import io.legado.app.data.entities.BookSource
import io.legado.app.data.entities.Bookmark
import io.legado.app.data.entities.rule.ReviewRule
import io.legado.app.exception.NoStackTraceException
import io.legado.app.help.AppWebDav
import io.legado.app.help.HighlightColors
import io.legado.app.help.HighlightStyle
import io.legado.app.help.HighlightStyles
import io.legado.app.help.IntentData
import io.legado.app.help.TTS
import io.legado.app.help.book.BookHelp
import io.legado.app.help.book.ContentProcessor
import io.legado.app.help.book.isAudio
import io.legado.app.help.book.isEpub
import io.legado.app.help.book.isLocal
import io.legado.app.help.book.isLocalTxt
import io.legado.app.help.book.isMobi
import io.legado.app.help.book.removeType
import io.legado.app.help.book.update
import io.legado.app.help.config.AppConfig
import io.legado.app.help.config.ReadBookConfig
import io.legado.app.help.config.ReadTipConfig
import io.legado.app.help.coroutine.Coroutine
import io.legado.app.help.source.getSourceType
import io.legado.app.help.storage.Backup
import io.legado.app.lib.dialogs.SelectItem
import io.legado.app.lib.dialogs.alert
import io.legado.app.lib.dialogs.selector
import io.legado.app.lib.theme.accentColor
import io.legado.app.lib.theme.bottomBackground
import io.legado.app.lib.theme.getPrimaryTextColor
import io.legado.app.model.ReadAloud
import io.legado.app.model.ReadBook
import io.legado.app.model.analyzeRule.AnalyzeRule
import io.legado.app.model.analyzeRule.AnalyzeRule.Companion.setChapter
import io.legado.app.model.analyzeRule.AnalyzeRule.Companion.setCoroutineContext
import io.legado.app.model.analyzeRule.AnalyzeUrl
import io.legado.app.model.analyzeRule.ReviewRuleParser
import io.legado.app.model.jsSource.JsSourceReview
import io.legado.app.utils.GSON
import io.legado.app.utils.fromJsonObject
import io.legado.app.utils.isJsonObject
import io.legado.app.model.localBook.EpubFile
import io.legado.app.model.localBook.MobiFile
import io.legado.app.receiver.NetworkChangedListener
import io.legado.app.receiver.TimeBatteryReceiver
import io.legado.app.service.BaseReadAloudService
import io.legado.app.ui.about.AppLogDialog
import io.legado.app.ui.book.bookmark.BookmarkDialog
import io.legado.app.ui.book.changesource.ChangeBookSourceDialog
import io.legado.app.ui.book.changesource.ChangeChapterSourceDialog
import io.legado.app.ui.book.info.BookInfoActivity
import io.legado.app.ui.book.read.config.AutoReadDialog
import io.legado.app.ui.book.read.config.BgTextConfigDialog.Companion.BG_COLOR
import io.legado.app.ui.book.read.config.BgTextConfigDialog.Companion.REVIEW_ICON_COLOR
import io.legado.app.ui.book.read.config.BgTextConfigDialog.Companion.TEXT_ACCENT_COLOR
import io.legado.app.ui.book.read.config.BgTextConfigDialog.Companion.TEXT_COLOR
import io.legado.app.ui.book.read.config.BgTextConfigDialog.Companion.UNDERLINE_COLOR
import io.legado.app.ui.book.read.config.MoreConfigDialog
import io.legado.app.ui.book.read.config.ReadAloudDialog
import io.legado.app.ui.book.read.config.ReaderMenuConfigDialog
import io.legado.app.ui.book.read.config.ReadStyleDialog
import io.legado.app.ui.book.read.config.TextSelectMenuConfigDialog
import io.legado.app.ui.book.read.config.TipConfigDialog.Companion.TITLE_COLOR
import io.legado.app.ui.book.read.config.TipConfigDialog.Companion.TITLE_NUMBER_COLOR
import io.legado.app.ui.book.read.config.TipConfigDialog.Companion.TIP_COLOR
import io.legado.app.ui.book.read.config.TipConfigDialog.Companion.TIP_DIVIDER_COLOR
import io.legado.app.ui.book.read.page.ContentTextView
import io.legado.app.ui.book.read.page.ReadView
import io.legado.app.ui.book.read.page.delegate.ScrollPageDelegate
import io.legado.app.ui.book.read.page.entities.PageDirection
import io.legado.app.ui.book.read.page.entities.TextPage
import io.legado.app.ui.book.read.page.provider.ChapterProvider
import io.legado.app.ui.book.read.page.provider.LayoutProgressListener
import io.legado.app.ui.book.searchContent.SearchContentActivity
import io.legado.app.ui.book.searchContent.SearchResult
import io.legado.app.model.SourceCallBack
import io.legado.app.ui.book.source.edit.BookSourceEditActivity
import io.legado.app.ui.book.toc.TocActivityResult
import io.legado.app.ui.book.toc.rule.TxtTocRuleDialog
import io.legado.app.ui.browser.WebViewActivity
import io.legado.app.ui.dict.DictDialog
import io.legado.app.ui.file.HandleFileContract
import io.legado.app.ui.highlight.HighlightRuleActivity
import io.legado.app.ui.highlight.edit.HighlightRuleEditDialog
import io.legado.app.ui.login.SourceLoginActivity
import io.legado.app.ui.replace.ReplaceRuleActivity
import io.legado.app.ui.replace.edit.ReplaceEditActivity
import io.legado.app.ui.widget.PopupAction
import io.legado.app.ui.widget.dialog.PhotoDialog
import io.legado.app.ui.widget.popupActionMenu
import io.legado.app.utils.ACache
import io.legado.app.utils.ColorUtils
import io.legado.app.utils.Debounce
import io.legado.app.utils.LogUtils
import io.legado.app.utils.NetworkUtils
import io.legado.app.utils.StartActivityContract
import io.legado.app.utils.buildMainHandler
import io.legado.app.utils.dismissDialogFragment
import io.legado.app.utils.dpToPx
import io.legado.app.utils.getPrefBoolean
import io.legado.app.utils.getPrefString
import io.legado.app.utils.hexString
import io.legado.app.utils.iconItemOnLongClick
import io.legado.app.utils.invisible
import io.legado.app.utils.isAbsUrl
import io.legado.app.utils.isTrue
import io.legado.app.utils.launch
import io.legado.app.utils.observeEvent
import io.legado.app.utils.observeEventSticky
import io.legado.app.utils.postEvent
import io.legado.app.utils.sendToClip
import io.legado.app.utils.showDialogFragment
import io.legado.app.utils.showHelp
import io.legado.app.utils.startActivity
import io.legado.app.utils.startActivityForBook
import io.legado.app.utils.sysScreenOffTime
import io.legado.app.utils.throttle
import io.legado.app.utils.toastOnUi
import io.legado.app.utils.visible
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.Dispatchers.Main
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import androidx.core.net.toUri
import androidx.lifecycle.Lifecycle
import com.script.rhino.runScriptWithContext
import io.legado.app.model.analyzeRule.AnalyzeUrl.Companion.paramPattern
import io.legado.app.ui.login.SourceLoginJsExtensions
import io.legado.app.ui.association.ImportBookSourceDialog

/**
 * 阅读界面
 */
class ReadBookActivity : BaseReadBookActivity(),
    View.OnTouchListener,
    ReadView.CallBack,
    TextActionMenu.CallBack,
    ContentTextView.CallBack,
    ReadMenu.CallBack,
    SearchMenu.CallBack,
    ReadAloudDialog.CallBack,
    ChangeBookSourceDialog.CallBack,
    ChangeChapterSourceDialog.CallBack,
    ReadBook.CallBack,
    AutoReadDialog.CallBack,
    TxtTocRuleDialog.CallBack,
    ColorPickerDialogListener,
    HighlightStyleDialog.StyleHost,
    LayoutProgressListener {

    private var openingPublisherLayout = false

    private val tocActivity =
        registerForActivityResult(TocActivityResult()) {
            it?.let {
                val highlightLayoutTitleLength =
                    (it[TocActivityResult.HIGHLIGHT_LAYOUT_TITLE_LENGTH_INDEX] as Int)
                        .takeUnless { titleLength ->
                            titleLength == TocActivityResult.NO_HIGHLIGHT_LAYOUT_TITLE_LENGTH
                        }
                viewModel.openChapter(
                    it[0] as Int,
                    it[1] as Int,
                    highlightLayoutTitleLength,
                    (it[TocActivityResult.HIGHLIGHT_ANCHOR_TEXT_INDEX] as String)
                        .takeIf(String::isNotEmpty),
                    pdfPageIndex = (it[TocActivityResult.PDF_PAGE_INDEX] as Int).takeIf { page -> page >= 0 }
                )
            }
        }
    private val sourceEditActivity =
        registerForActivityResult(StartActivityContract(BookSourceEditActivity::class.java)) {
            if (it.resultCode == RESULT_OK) {
                viewModel.upBookSource {
                    resetReviewSummaryState()
                    ReadBook.loadContent(resetPageOffset = false)
                    upMenuView()
                }
            }
        }
    private val replaceActivity =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) {
                viewModel.replaceRuleChanged()
            }
        }
    private val searchContentActivity =
        registerForActivityResult(StartActivityContract(SearchContentActivity::class.java)) {
            val data = it.data ?: return@registerForActivityResult
            val key = data.getLongExtra("key", System.currentTimeMillis())
            val index = data.getIntExtra("index", 0)
            val searchResult = IntentData.get<SearchResult>("searchResult$key")
            val searchResultList = IntentData.get<List<SearchResult>>("searchResultList$key")
            if (searchResult != null && searchResultList != null) {
                viewModel.searchContentQuery = searchResult.query
                binding.searchMenu.upSearchResultList(searchResultList)
                isShowingSearchResult = true
                viewModel.searchResultIndex = index
                binding.searchMenu.updateSearchResultIndex(index)
                binding.searchMenu.selectedSearchResult?.let { currentResult ->
                    ReadBook.saveCurrentBookProgress() //退出全文搜索恢复此时进度
                    skipToSearch(currentResult)
                    showActionMenu()
                }
            }
        }
    private val bookInfoActivity =
        registerForActivityResult(StartActivityContract(BookInfoActivity::class.java)) {
            if (it.resultCode == RESULT_OK) {
                setResult(RESULT_DELETED)
                super.finish()
            } else {
                ReadBook.loadOrUpContent()
            }
        }
    private val selectImageDir = registerForActivityResult(HandleFileContract()) {
        it.uri?.let { uri ->
            ACache.get().put(AppConst.imagePathKey, uri.toString())
            viewModel.saveImage(it.value, uri)
        }
    }
    private var menu: Menu? = null
    private var backupJob: Job? = null
    private var bookmarkJob: Job? = null
    private var replacePreviewJob: Job? = null
    private var replacePreviewGeneration = 0L
    private val bookmarkToggleMutex = Mutex()
    private var bookmarkTogglePending = false
    private var bookmarkBookKey: Pair<String, String>? = null
    private var bookmarks: List<Bookmark> = emptyList()
    private var tts: TTS? = null
    val textActionMenu: TextActionMenu by lazy {
        TextActionMenu(this, this)
    }
    private val popupAction: PopupAction by lazy {
        PopupAction(this)
    }
    private var readerOverflowPopup: PopupAction? = null
    override val isInitFinish: Boolean get() = viewModel.isInitFinish
    override val isScroll: Boolean get() = binding.readView.isScroll
    private val isAutoPage get() = binding.readView.isAutoPage
    override var isShowingSearchResult = false
    override var isSelectingSearchResult = false
        set(value) {
            field = value && isShowingSearchResult
        }
    private val timeBatteryReceiver = TimeBatteryReceiver()
    private var screenTimeOut: Long = 0
    private var loadStates: Boolean = false
    override val pageFactory get() = binding.readView.pageFactory
    override val pageDelegate get() = binding.readView.pageDelegate
    override val headerHeight: Int get() = binding.readView.curPage.headerHeight
    override val imgBgPaddingStart: Int get() = binding.readView.curPage.imgBgPaddingStart
    private val nextPageDebounce by lazy { Debounce { keyPage(PageDirection.NEXT) } }
    private val prevPageDebounce by lazy { Debounce { keyPage(PageDirection.PREV) } }
    private var bookChanged = false
    private var pageChanged = false
    private val aloudControls by lazy {
        ReadAloudControls(binding.readAloudFloatBarContainer) { updateReadAloudFloatBar() }
    }
    private val restoreAloudFollowRunnable = Runnable { restoreAloudFollowOnVisiblePage() }
    /** 最近一次朗读进度的章内字符位置; 供"回到朗读位置"在同章内即时跳转 */
    private var lastReadAloudChapterStart = -1
    private var lastReadAloudChapterIndex = -1
    private val handler by lazy { buildMainHandler() }
    private val screenOffRunnable by lazy { Runnable { keepScreenOn(false) } }
    private val executor = ReadBook.executor
    private val upSeekBarThrottle = throttle(200) {
        runOnUiThread {
            upSeekBarProgress()
            binding.readMenu.upSeekBar()
        }
    }
    private var reviewSummaryAppliedKey: String? = null
    private var reviewSummaryLoadingKey: String? = null
    private var lastReviewDialogRequestAt = 0L
    private var reviewSummaryRequestToken = 0L
    private val reviewSummaryCache = object :
        LinkedHashMap<String, ReviewRuleParser.SummaryResult>(8, 0.75f, true) {
        override fun removeEldestEntry(
            eldest: MutableMap.MutableEntry<String, ReviewRuleParser.SummaryResult>
        ): Boolean = size > 5
    }
    private val reviewSummaryPrefetchingKeys = HashSet<String>()

    //恢复跳转前进度对话框的交互结果
    private var confirmRestoreProcess: Boolean? = null
    private val networkChangedListener by lazy {
        NetworkChangedListener(this)
    }
    private var justInitData: Boolean = false
    private var syncDialog: AlertDialog? = null

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        editingHighlight = savedInstanceState?.getParcelable(STATE_EDITING_HIGHLIGHT)
        super.onCreate(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBundle("pdfZoom", binding.readView.pdfZoom.save())
        outState.putBundle("aloudControls", aloudControls.save())
        editingHighlight?.let { outState.putParcelable(STATE_EDITING_HIGHLIGHT, it) }
        super.onSaveInstanceState(outState)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel.pendingSourceReimport.observe(this) { showPendingSourceReimport() }
        viewModel.resourceRefreshing.observe(this) { loading ->
            if (binding.readView.pageFactory.isRefreshingResources != loading) {
                if (loading) binding.readView.updateScrollReadPosition()
                binding.readView.pageFactory.isRefreshingResources = loading
                upContent()
            }
        }
        binding.readView.pdfZoom.restore(savedInstanceState?.getBundle("pdfZoom"))
        aloudControls.restore(savedInstanceState?.getBundle("aloudControls"))
        binding.cursorLeft.setColorFilter(accentColor)
        binding.cursorRight.setColorFilter(accentColor)
        binding.cursorLeft.setOnTouchListener(this)
        binding.cursorRight.setOnTouchListener(this)
        binding.readAloudFloatBarContainer.ivPauseAloud.setOnClickListener {
            if (BaseReadAloudService.pause) ReadAloud.resume(this) else ReadAloud.pause(this)
        }
        binding.readAloudFloatBarContainer.llBackToSpeech.setOnClickListener {
            backToSpeakingPosition()
        }
        binding.readAloudFloatBarContainer.llReadFromHere.setOnClickListener {
            ReadBook.readAloud()
        }
        window.setBackgroundDrawable(null)
        upScreenTimeOut()
        ReadBook.register(this)
        onBackPressedDispatcher.addCallback(this) {
            if (isShowingSearchResult) {
                exitSearchMenu()
                restoreLastBookProcess()
                return@addCallback
            }
            //拦截返回供恢复阅读进度
            if (ReadBook.lastBookProgress != null && confirmRestoreProcess != false) {
                restoreLastBookProcess()
                return@addCallback
            }
            if (BaseReadAloudService.isPlay()) {
                ReadAloud.pause(this@ReadBookActivity)
                toastOnUi(R.string.read_aloud_pause)
                return@addCallback
            }
            if (isAutoPage) {
                autoPageStop()
                return@addCallback
            }
            if (getPrefBoolean("disableReturnKey") && !menuLayoutIsVisible) {
                return@addCallback
            }
            finish()
        }
    }

    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)
        viewModel.initReadBookConfig(intent)
        ChapterProvider.clearReviewProviders()
        binding.readView.doOnLayout {
            Looper.myQueue().addIdleHandler {
                viewModel.initData(intent)
                false
            }
        }
        justInitData = true
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        editingHighlight = null
        resetBookmarkObserver()
        resetReviewSummaryState()
        viewModel.initData(intent)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        upSystemUiVisibility()
        if (hasFocus) {
            binding.readMenu.upBrightnessState()
        } else if (!menuLayoutIsVisible) {
            ReadBook.cancelPreDownloadTask()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        upSystemUiVisibility()
        binding.readView.upStatusBar()
        upBookmarkIndicator()
    }

    override fun onTopResumedActivityChanged(isTopResumedActivity: Boolean) {
        if (!isTopResumedActivity) {
            ReadBook.cancelPreDownloadTask()
        }
    }

    @SuppressLint("UnspecifiedRegisterReceiverFlag")
    override fun onResume() {
        super.onResume()
        ReadBook.readStartTime = System.currentTimeMillis()
        if (bookChanged) {
            bookChanged = false
            ReadBook.callBack = this
            viewModel.initData(intent)
            justInitData = true
        } else {
            //web端阅读时，app处于阅读界面，本地记录会覆盖web保存的进度，在此处恢复
            ReadBook.webBookProgress?.let {
                ReadBook.setProgress(it)
                ReadBook.webBookProgress = null
            }
        }
        upSystemUiVisibility()
        registerReceiver(timeBatteryReceiver, timeBatteryReceiver.filter)
        binding.readView.upTime()
        updateReadAloudFloatBar()
        screenOffTimerStart()
        // 网络监听，当从无网切换到网络环境时同步进度（注意注册的同时就会收到监听，因此界面激活时无需重复执行同步操作）
        networkChangedListener.register()
        networkChangedListener.onNetworkChanged = {
            // 当网络是可用状态且无需初始化时同步进度（初始化中已有同步进度逻辑）
            if (AppConfig.syncBookProgressPlus && NetworkUtils.isAvailable() && !justInitData && ReadBook.inBookshelf) {
                ReadBook.syncProgress({ progress -> sureNewProgress(progress) })
            }
        }
    }

    override fun onPostResume() {
        super.onPostResume()
        showPendingSourceReimport()
    }

    private fun showPendingSourceReimport() {
        val pending = viewModel.pendingSourceReimport.value ?: return
        if (!lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) ||
            supportFragmentManager.isStateSaved) return
        viewModel.pendingSourceReimport.value = null
        if (ReadBook.book?.bookUrl != pending.bookUrl || ReadBook.book?.origin != pending.sourceUrl) return
        if (supportFragmentManager.findFragmentByTag("readerSourceReimport") != null) return
        ImportBookSourceDialog(pending.json, reimportBookUrl = pending.bookUrl,
            reimportSourceUrl = pending.sourceUrl).show(supportFragmentManager, "readerSourceReimport")
    }

    override fun onPause() {
        super.onPause()
        binding.readView.cancelTouchGestures()
        autoPageStop()
        backupJob?.cancel()
        binding.readView.updateScrollReadPosition()
        ReadBook.saveRead()
        ReadBook.cancelPreDownloadTask()
        unregisterReceiver(timeBatteryReceiver)
        upSystemUiVisibility()
        if (!BuildConfig.DEBUG && ReadBook.inBookshelf) {
            if (AppConfig.syncBookProgressPlus) {
                ReadBook.syncProgress()
            } else {
                ReadBook.uploadProgress()
            }
        }
        if (!BuildConfig.DEBUG) {
            Backup.autoBack(this)
        }
        justInitData = false
        networkChangedListener.unRegister()
    }

    override fun onCompatCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.book_read, menu)
        menu.iconItemOnLongClick(R.id.menu_change_source) {
            showChangeSourceMenu(it)
        }
        menu.iconItemOnLongClick(R.id.menu_refresh) {
            showRefreshMenu(it)
        }
        binding.readMenu.refreshMenuColorFilter()
        return super.onCompatCreateOptionsMenu(menu)
    }

    override fun onShowActivityOverflowMenu(anchor: View, menu: Menu): Boolean {
        showReaderOverflowMenu(anchor, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        this.menu = menu
        upMenu()
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onMenuOpened(featureId: Int, menu: Menu): Boolean {
        menu.findItem(R.id.menu_same_title_removed)?.isChecked =
            ReadBook.curTextChapter?.sameTitleRemoved == true
        return super.onMenuOpened(featureId, menu)
    }

    /**
     * 更新菜单
     */
    private fun upMenu() {
        val menu = menu ?: return
        // Keep configuration reachable if the shared popup must fall back to the native menu.
        menu.findItem(R.id.menu_reader_all_features)?.isVisible = true
        val book = ReadBook.book ?: return
        val onLine = !book.isLocal
        for (i in 0 until menu.size) {
            val item = menu[i]
            when (item.groupId) {
                R.id.menu_group_on_line -> item.isVisible = onLine
                R.id.menu_group_local -> item.isVisible = !onLine
                R.id.menu_group_text -> item.isVisible = book.isLocalTxt
                R.id.menu_group_epub -> item.isVisible = book.isEpub
                else -> when (item.itemId) {
                    R.id.menu_enable_replace -> {
                        item.isVisible = !AppConfig.manualReplaceRule
                        item.isChecked = book.getUseReplaceRule()
                    }
                    R.id.menu_manual_replace_rule -> item.isVisible = AppConfig.manualReplaceRule
                    R.id.menu_re_segment -> item.isChecked = book.getReSegment()
//                    R.id.menu_enable_review -> {
//                        item.isVisible = BuildConfig.DEBUG
//                        item.isChecked = AppConfig.enableReview
//                    }

                    R.id.menu_reimport_source -> item.isVisible = onLine
                    R.id.menu_reverse_content -> {
                        item.isVisible = onLine
                        item.isChecked = ReadBook.curTextChapter?.chapter?.takeIf {
                            it.bookUrl == book.bookUrl && it.index == ReadBook.durChapterIndex
                        }?.let { BookHelp.isContentReversed(book, it) } == true
                    }
                    R.id.menu_del_ruby_tag -> item.isChecked = book.getDelTag(Book.rubyTag)
                    R.id.menu_del_h_tag -> item.isChecked = book.getDelTag(Book.hTag)
                }
            }
        }
        lifecycleScope.launch {
            val show = ReadBook.inBookshelf && withContext(IO) {
                AppWebDav.isOk
            }
            menu.findItem(R.id.menu_get_progress)?.isVisible = show
            menu.findItem(R.id.menu_cover_progress)?.isVisible = show
            menu.findItem(R.id.menu_reader_more)?.isVisible = hasHiddenReaderItems(menu)
        }
        menu.findItem(R.id.menu_reader_more)?.isVisible = hasHiddenReaderItems(menu)
    }

    @SuppressLint("RestrictedApi")
    private fun showReaderOverflowMenu(anchor: View, menu: Menu) {
        val overflowItems = menu.visibleReaderOverflowItems()
        val visibleByKey = menu.readerOverflowItemsByKey()
        val config = loadReaderMenuConfig(this)
        val primaryItems = config.primary.mapNotNull { visibleByKey[it] }.toMutableList()
        val moreItems = config.more.mapNotNull { visibleByKey[it] }
        val placedIds = (primaryItems + moreItems).mapTo(HashSet()) { it.itemId }

        // Keep newly added overflow actions available until they get a config entry.
        overflowItems
            .filter { item ->
                item.itemId !in placedIds &&
                    item.itemId != R.id.menu_reader_more &&
                    item.itemId != R.id.menu_reader_all_features
            }
            .forEach { primaryItems += it }

        val popupItems = buildList {
            addAll(primaryItems.map(::toReaderPopupItem))
            if (moreItems.isNotEmpty()) {
                add(
                    PopupAction.PopupActionItem(
                        title = getString(R.string.reader_menu_more),
                        value = ACTION_READER_MORE
                    )
                )
            }
            add(
                PopupAction.PopupActionItem(
                    title = getString(R.string.reader_menu_all_features),
                    value = ACTION_READER_CONFIG
                )
            )
        }
        readerOverflowPopup?.dismiss()
        val popup = PopupAction(this)
        readerOverflowPopup = popup
        popup.setVertical(true)
        popup.setActionItems(popupItems)
        popup.onActionClick = { action ->
            popup.dismiss()
            when {
                action == ACTION_READER_MORE -> showReaderMoreMenu(anchor, menu)
                action == ACTION_READER_CONFIG -> showReaderMenuConfig()
                action.startsWith(ACTION_READER_ITEM_PREFIX) -> action
                    .removePrefix(ACTION_READER_ITEM_PREFIX)
                    .toIntOrNull()
                    ?.let { id -> menu.findItem(id)?.let(::onCompatOptionsItemSelected) }
            }
        }
        popup.setOnDismissListener {
            if (readerOverflowPopup === popup) readerOverflowPopup = null
        }
        popup.showAsDropDown(anchor, 0, 4.dpToPx())
    }

    @SuppressLint("RestrictedApi")
    private fun showReaderMoreMenu(anchor: View, menu: Menu) {
        val visibleByKey = menu.readerOverflowItemsByKey()
        val config = loadReaderMenuConfig(this)
        val moreItems = config.more.mapNotNull { visibleByKey[it] }
        if (moreItems.isEmpty()) return
        readerOverflowPopup?.dismiss()
        val popup = PopupAction(this)
        readerOverflowPopup = popup
        popup.setVertical(true)
        popup.setActionItems(moreItems.map(::toReaderPopupItem))
        popup.onActionClick = { action ->
            popup.dismiss()
            action.removePrefix(ACTION_READER_ITEM_PREFIX)
                .toIntOrNull()
                ?.let { id -> menu.findItem(id)?.let(::onCompatOptionsItemSelected) }
        }
        popup.setOnDismissListener {
            if (readerOverflowPopup === popup) readerOverflowPopup = null
        }
        popup.showAsDropDown(anchor, 0, 4.dpToPx())
    }

    private fun toReaderPopupItem(item: MenuItem): PopupAction.PopupActionItem {
        return PopupAction.PopupActionItem(
            title = item.title?.toString().orEmpty(),
            value = ACTION_READER_ITEM_PREFIX + item.itemId,
            icon = item.icon?.constantState?.newDrawable()?.mutate(),
            enabled = item.isEnabled,
            checkable = item.isCheckable,
            checked = item.isChecked
        )
    }

    private fun hasHiddenReaderItems(menu: Menu): Boolean {
        val visibleKeys = menu.readerOverflowItemsByKey().keys
        return loadReaderMenuConfig(this).more.any(visibleKeys::contains)
    }

    @SuppressLint("RestrictedApi")
    private fun Menu.visibleReaderOverflowItems(): List<MenuItem> {
        return (0 until size()).mapNotNull { index ->
            getItem(index).takeIf { item ->
                if (!item.isVisible) return@takeIf false
                val impl = item as? MenuItemImpl ?: return@takeIf false
                impl.requiresOverflow() || impl.requestsActionButton() && !impl.isActionButton
            }
        }
    }

    @SuppressLint("RestrictedApi")
    private fun Menu.readerOverflowItemsByKey(): Map<String, MenuItem> {
        val overflowIds = visibleReaderOverflowItems().mapTo(HashSet()) { it.itemId }
        return ReaderMenuItem.entries.mapNotNull { descriptor ->
            descriptor.findVisible(this)
                ?.takeIf { it.itemId in overflowIds }
                ?.let { descriptor.key to it }
        }.toMap()
    }

    private fun showChangeSourceMenu(anchor: View) {
        popupActionMenu(this) {
            item(getString(R.string.chapter_change_source), "chapter")
            item(getString(R.string.batch_chapter_change_source), "batchChapter")
            item(getString(R.string.book_change_source), "book")
        }.show(anchor) { action ->
            when (action) {
                "chapter" -> showChapterChangeSource()
                "batchChapter" -> showChapterChangeSource(batchMode = true)
                "book" -> showBookChangeSource()
            }
        }
    }

    private fun showRefreshMenu(anchor: View) {
        popupActionMenu(this) {
            item(getString(R.string.menu_refresh_dur), "dur")
            item(getString(R.string.menu_refresh_after), "after")
            item(getString(R.string.menu_refresh_all), "all")
            item(getString(R.string.menu_refresh_resources), "resources")
        }.show(anchor) { action ->
            when (action) {
                "dur" -> refreshDurChapter()
                "after" -> refreshAfterChapters()
                "all" -> refreshAllChapters()
                "resources" -> {
                    resetReviewSummaryState()
                    ReadBook.book?.let { viewModel.refreshResources(it, includePreloaded = true) }
                }
            }
        }
    }

    private fun showBookChangeSource() {
        binding.readMenu.runMenuOut()
        ReadBook.book?.let {
            showDialogFragment(ChangeBookSourceDialog(it.name, it.author))
        }
    }

    private fun showChapterChangeSource(batchMode: Boolean = false) {
        lifecycleScope.launch {
            val book = ReadBook.book ?: return@launch
            val chapter = appDb.bookChapterDao.getChapter(book.bookUrl, ReadBook.durChapterIndex)
                ?: return@launch
            binding.readMenu.runMenuOut()
            showDialogFragment(
                ChangeChapterSourceDialog(
                    book.name,
                    book.author,
                    chapter.index,
                    chapter.title,
                    batchMode = batchMode,
                )
            )
        }
    }

    private fun refreshDurChapter() {
        resetReviewSummaryState()
        if (ReadBook.bookSource == null) {
            upContent()
        } else {
            ReadBook.book?.let {
                if (viewModel.resourceThemeChanged(it)) {
                    viewModel.refreshResources(it, includePreloaded = false)
                    return@let
                }
                ReadBook.preserveCurrentPositionForRefresh()
                ReadBook.curTextChapter = null
                binding.readView.upContent()
                viewModel.refreshContentDur(it)
            }
        }
    }

    private fun refreshAfterChapters() {
        resetReviewSummaryState()
        if (ReadBook.bookSource == null) {
            upContent()
        } else {
            ReadBook.book?.let {
                ReadBook.clearTextChapter()
                binding.readView.upContent()
                viewModel.refreshContentAfter(it)
            }
        }
    }

    private fun refreshAllChapters() {
        if (ReadBook.bookSource == null) {
            resetReviewSummaryState()
            upContent()
        } else {
            ReadBook.book?.let {
                refreshContentAll(it)
            }
        }
    }

    /**
     * 菜单
     */
    override fun onCompatOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_epub_publisher -> {
                openPublisherLayout()
                return true
            }
            R.id.menu_reader_more -> {
                val toolbar = binding.readMenu.findViewById<View>(R.id.toolbar)
                menu?.let { showReaderMoreMenu(toolbar, it) }
                return true
            }

            R.id.menu_reader_all_features -> {
                showReaderMenuConfig()
                return true
            }

            R.id.menu_change_source -> showBookChangeSource()

            R.id.menu_refresh -> refreshDurChapter()

            R.id.menu_download -> showDownloadDialog()
            R.id.menu_add_bookmark -> addBookmark()
            R.id.menu_highlight_rule -> startActivity<HighlightRuleActivity>()
            R.id.menu_simulated_reading -> showSimulatedReading()
            R.id.menu_edit_content -> ContentEditDialog.newInstance()?.let {
                showDialogFragment(it)
            }
            R.id.menu_reimport_source -> viewModel.prepareSourceReimport()
            R.id.menu_update_toc -> ReadBook.book?.let {
                if (it.isEpub) {
                    BookHelp.clearCache(it)
                    EpubFile.clear()
                }
                if (it.isMobi) {
                    MobiFile.clear()
                }
                loadChapterList(it)
            }

            R.id.menu_enable_replace -> changeReplaceRuleState()
            R.id.menu_manual_replace_rule -> showDialogFragment<ManualReplaceRulesDialog>()
            R.id.menu_re_segment -> ReadBook.book?.let {
                it.setReSegment(!it.getReSegment())
                item.isChecked = it.getReSegment()
                ReadBook.loadContent(false)
            }

//            R.id.menu_enable_review -> {
//                AppConfig.enableReview = !AppConfig.enableReview
//                item.isChecked = AppConfig.enableReview
//                ReadBook.loadContent(false)
//            }

            R.id.menu_del_ruby_tag -> ReadBook.book?.let {
                item.isChecked = !item.isChecked
                if (item.isChecked) {
                    it.addDelTag(Book.rubyTag)
                } else {
                    it.removeDelTag(Book.rubyTag)
                }
                refreshContentAll(it)
            }

            R.id.menu_del_h_tag -> ReadBook.book?.let {
                item.isChecked = !item.isChecked
                if (item.isChecked) {
                    it.addDelTag(Book.hTag)
                } else {
                    it.removeDelTag(Book.hTag)
                }
                refreshContentAll(it)
            }

            R.id.menu_page_anim -> showPageAnimConfig {
                binding.readView.upPageAnim()
                ReadBook.loadContent(false)
            }

            R.id.menu_log -> showDialogFragment<AppLogDialog>()
            R.id.menu_toc_regex -> showDialogFragment(
                TxtTocRuleDialog(ReadBook.book?.tocUrl)
            )

            R.id.menu_reverse_content -> ReadBook.book?.let {
                viewModel.reverseContent(it)
            }

            R.id.menu_set_charset -> showCharsetConfig()
            R.id.menu_image_style -> {
                val imgStyles =
                    arrayListOf(
                        Book.imgStyleDefault, Book.imgStyleFull, Book.imgStyleText,
                        Book.imgStyleSingle
                    )
                selector(
                    R.string.image_style,
                    imgStyles
                ) { _, index ->
                    val imageStyle = imgStyles[index]
                    ReadBook.book?.setImageStyle(imageStyle)
                    if (imageStyle == Book.imgStyleSingle) {
                        ReadBook.book?.setPageAnim(0)  // 切换图片样式single后，自动切换为覆盖
                        binding.readView.upPageAnim()
                    }
                    ReadBook.loadContent(false)
                }
            }

            R.id.menu_get_progress -> ReadBook.book?.let {
                viewModel.syncBookProgress(it) { progress ->
                    sureSyncProgress(progress)
                }
            }

            R.id.menu_cover_progress -> ReadBook.book?.let {
                ReadBook.uploadProgress(true) { toastOnUi(R.string.upload_book_success) }
            }

            R.id.menu_same_title_removed -> {
                ReadBook.book?.let {
                    val contentProcessor = ContentProcessor.get(it)
                    val textChapter = ReadBook.curTextChapter
                    if (textChapter != null
                        && !textChapter.sameTitleRemoved
                        && !contentProcessor.removeSameTitleCache.contains(
                            textChapter.chapter.getFileName("nr")
                        )
                    ) {
                        toastOnUi("未找到可移除的重复标题")
                    }
                }
                viewModel.reverseRemoveSameTitle()
            }

            R.id.menu_effective_replaces -> showDialogFragment<EffectiveReplacesDialog>()

            R.id.menu_help -> showHelp()
        }
        return super.onCompatOptionsItemSelected(item)
    }

    private fun openPublisherLayout(useNativePosition: Boolean = true) {
        if (openingPublisherLayout) return
        val book = ReadBook.book?.takeIf { it.isEpub } ?: return
        openingPublisherLayout = true
        binding.readView.updateScrollReadPosition()
        autoPageStop()
        if (BaseReadAloudService.isRun) ReadAloud.stop(this)
        val text = ReadBook.curTextChapter?.pages?.joinToString("") { it.text }.orEmpty()
        val position = ReadBook.durChapterPos.coerceIn(0, text.length)
        book.config.epubUsePublisherLayout = true
        if (useNativePosition) book.config.epubPublisherLocator = null
        ReadBook.saveRead()
        val publisherIntent = Intent(this, EpubPublisherActivity::class.java)
            .putExtra("bookUrl", book.bookUrl)
            .putExtra("index", ReadBook.durChapterIndex)
            .putExtra("chapterPos", position)
        if (useNativePosition) publisherIntent
            .putExtra("publisherQuote", text.substring(position).take(64))
            .putExtra("publisherFraction", if (text.isEmpty()) 0.0 else position.toDouble() / text.length)
        startActivity(publisherIntent)
        finish()
    }

    private fun refreshContentAll(book: Book) {
        resetReviewSummaryState()
        ReadBook.clearTextChapter()
        binding.readView.upContent()
        viewModel.refreshContentAll(book)
    }

    private fun resetReviewSummaryState() {
        reviewSummaryRequestToken++
        reviewSummaryAppliedKey = null
        reviewSummaryLoadingKey = null
        synchronized(reviewSummaryCache) {
            reviewSummaryCache.clear()
        }
        synchronized(reviewSummaryPrefetchingKeys) {
            reviewSummaryPrefetchingKeys.clear()
        }
        ChapterProvider.clearReviewProviders()
    }

    /**
     * 按键拦截,显示菜单
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val action = event.action
        val isDown = action == 0

        if (keyCode == KeyEvent.KEYCODE_MENU) {
            if (isDown && !binding.readMenu.canShowMenu) {
                binding.readMenu.runMenuIn()
                return true
            }
            if (!isDown && !binding.readMenu.canShowMenu) {
                binding.readMenu.canShowMenu = true
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    /**
     * 鼠标滚轮和手表旋钮事件
     */
    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_SCROLL) {
            val axisValue = when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                    event.isFromSource(InputDevice.SOURCE_ROTARY_ENCODER) ->
                    event.getAxisValue(MotionEvent.AXIS_SCROLL)

                event.source and InputDevice.SOURCE_CLASS_POINTER != 0 ->
                    event.getAxisValue(MotionEvent.AXIS_VSCROLL)

                else -> return super.onGenericMotionEvent(event)
            }
            if (!axisValue.isFinite() || axisValue == 0f) {
                return super.onGenericMotionEvent(event)
            }
            LogUtils.d("onGenericMotionEvent", "axisValue = $axisValue")
            val direction = if (axisValue < 0f) PageDirection.NEXT else PageDirection.PREV
            mouseWheelPage(direction, axisValue)
            return true
        }
        return super.onGenericMotionEvent(event)
    }

    /**
     * 按键事件
     */
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (menuLayoutIsVisible) {
            return super.onKeyDown(keyCode, event)
        }
        val longPress = event.repeatCount > 0
        when {
            isPrevKey(keyCode) -> {
                handleKeyPage(PageDirection.PREV, longPress)
                return true
            }

            isNextKey(keyCode) -> {
                handleKeyPage(PageDirection.NEXT, longPress)
                return true
            }
        }
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> if (volumeKeyPage(PageDirection.PREV, longPress)) {
                return true
            }

            KeyEvent.KEYCODE_VOLUME_DOWN -> if (volumeKeyPage(PageDirection.NEXT, longPress)) {
                return true
            }

            KeyEvent.KEYCODE_PAGE_UP -> {
                handleKeyPage(PageDirection.PREV, longPress)
                return true
            }

            KeyEvent.KEYCODE_PAGE_DOWN -> {
                handleKeyPage(PageDirection.NEXT, longPress)
                return true
            }

            KeyEvent.KEYCODE_SPACE -> {
                handleKeyPage(PageDirection.NEXT, longPress)
                return true
            }
        }

        return super.onKeyDown(keyCode, event)
    }

    /**
     * 松开按键事件
     */
    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN -> {
                if (volumeKeyPage(PageDirection.NONE, false)) {
                    return true
                }
            }

        }
        return super.onKeyUp(keyCode, event)
    }

    // 按下点到光标图标中心的偏移
    private var cursorTouchOffsetX = 0f
    private var cursorTouchOffsetY = 0f

    // 光标图标尺寸, 不含扩大触摸范围的内边距
    private val View.iconWidth get() = width - paddingLeft - paddingRight
    private val View.iconHeight get() = height - paddingTop - paddingBottom

    /**
     * view触摸,文字选择
     */
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouch(v: View, event: MotionEvent): Boolean = binding.run {
        if (!binding.readView.isTextSelected) {
            return false
        }
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                textActionMenu.dismiss()
                cursorTouchOffsetX =
                    SelectCursorGeometry.touchOffset(event.x, v.paddingLeft, v.iconWidth)
                cursorTouchOffsetY =
                    SelectCursorGeometry.touchOffset(event.y, v.paddingTop, v.iconHeight)
            }

            MotionEvent.ACTION_MOVE -> {
                val rawX = event.rawX + cursorTouchOffsetX
                val rawY = event.rawY + cursorTouchOffsetY
                when (v.id) {
                    R.id.cursor_left -> if (!readView.curPage.getReverseStartCursor()) {
                        readView.selectStartMoveAtRaw(
                            rawX + cursorLeft.iconWidth,
                            rawY - cursorLeft.iconHeight
                        )
                    } else {
                        readView.selectEndMoveAtRaw(
                            rawX - cursorRight.iconWidth,
                            rawY - cursorRight.iconHeight
                        )
                    }

                    R.id.cursor_right -> if (readView.curPage.getReverseEndCursor()) {
                        readView.selectStartMoveAtRaw(
                            rawX + cursorLeft.iconWidth,
                            rawY - cursorLeft.iconHeight
                        )
                    } else {
                        readView.selectEndMoveAtRaw(
                            rawX - cursorRight.iconWidth,
                            rawY - cursorRight.iconHeight
                        )
                    }
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                readView.dismissTextMagnifier()
                readView.curPage.resetReverseCursor()
                showTextActionMenu()
            }
        }
        return true
    }

    /**
     * 更新文字选择开始位置
     */
    override fun upSelectedStart(x: Float, y: Float, top: Float) = binding.run {
        cursorLeft.x =
            SelectCursorGeometry.startCursorX(x, cursorLeft.width, cursorLeft.paddingRight)
        cursorLeft.y = SelectCursorGeometry.cursorY(y, cursorLeft.paddingTop)
        cursorLeft.visible(true)
        textMenuPosition.x = x
        textMenuPosition.y = top
    }

    /**
     * 更新文字选择结束位置
     */
    override fun upSelectedEnd(x: Float, y: Float) = binding.run {
        cursorRight.x = SelectCursorGeometry.endCursorX(x, cursorRight.paddingLeft)
        cursorRight.y = SelectCursorGeometry.cursorY(y, cursorRight.paddingTop)
        cursorRight.visible(true)
    }

    /**
     * 取消文字选择
     */
    override fun onCancelSelect() = binding.run {
        cursorLeft.invisible()
        cursorRight.invisible()
        textActionMenu.dismiss()
    }

    override fun onLongScreenshotTouchEvent(event: MotionEvent): Boolean {
        return binding.readView.onTouchEvent(event)
    }

    /**
     * 显示文本操作菜单
     */
    override fun showTextActionMenu() {
        textActionMenu.show(
            binding.textMenuPosition,
            binding.root.rootView.height,
            binding.textMenuPosition.x.toInt(),
            binding.textMenuPosition.y.toInt(),
            binding.cursorLeft.y.toInt() + binding.cursorLeft.height,
            binding.cursorRight.x.toInt(),
            binding.cursorRight.y.toInt() + binding.cursorRight.height
        )
    }

    private var editingHighlightTime: Long? = null
    private var editingHighlightSnapshot: BookHighlight? = null
    private var editingHighlight: BookHighlight?
        get() {
            val time = editingHighlightTime ?: return null
            val snapshot = editingHighlightSnapshot
            return ReadBook.highlights.firstOrNull {
                it.time == time && (snapshot == null ||
                        it.bookName == snapshot.bookName && it.bookAuthor == snapshot.bookAuthor)
            } ?: snapshot?.takeIf { it.time == time }
        }
        set(value) {
            editingHighlightTime = value?.time
            editingHighlightSnapshot = value
        }
    private var highlightStyleDialog: HighlightStyleDialog? = null
    private var highlightPopup: PopupAction? = null

    private fun showHighlightActionMenu(highlight: BookHighlight, x: Float, y: Float) {
        editingHighlight = highlight
        binding.textMenuPosition.x = x
        binding.textMenuPosition.y = y
        highlightPopup?.dismiss()
        highlightPopup = popupActionMenu(this) {
            item(getString(R.string.highlight_style), ACTION_HIGHLIGHT_STYLE)
            item(getString(R.string.highlight_note), ACTION_HIGHLIGHT_NOTE)
            item(getString(R.string.highlight_create_rule), ACTION_HIGHLIGHT_CREATE_RULE)
            item(getString(android.R.string.copy), ACTION_HIGHLIGHT_COPY)
            item(getString(R.string.delete), ACTION_HIGHLIGHT_DELETE)
            danger(ACTION_HIGHLIGHT_DELETE)
        }.show(binding.textMenuPosition) { action ->
            when (action) {
                ACTION_HIGHLIGHT_STYLE -> {
                    val dialog = HighlightStyleDialog()
                    highlightStyleDialog = dialog
                    showDialogFragment(dialog)
                }

                ACTION_HIGHLIGHT_NOTE -> showDialogFragment(HighlightNoteDialog(highlight))
                ACTION_HIGHLIGHT_CREATE_RULE -> showDialogFragment(
                    HighlightRuleEditDialog.create(
                        pattern = highlight.bookText,
                        scope = ReadBook.book?.name,
                        style = highlight.style
                    )
                )
                ACTION_HIGHLIGHT_COPY -> sendToClip(highlight.bookText)
                ACTION_HIGHLIGHT_DELETE -> {
                    ReadBook.removeHighlight(highlight)
                    if (editingHighlight?.time == highlight.time) editingHighlight = null
                }
            }
        }
    }

    override fun onHighlightClick(highlight: BookHighlight, x: Float, y: Float) {
        showHighlightActionMenu(highlight, x, y)
    }

    override fun onHighlightRuleClick(ruleId: Long, x: Float, y: Float) {
        binding.textMenuPosition.x = x
        binding.textMenuPosition.y = y
        highlightPopup?.dismiss()
        highlightPopup = popupActionMenu(this) {
            item(getString(R.string.edit), ACTION_HIGHLIGHT_RULE_EDIT)
            item(getString(R.string.highlight_rule), ACTION_HIGHLIGHT_RULE_MANAGE)
            item(getString(R.string.highlight_rule_disable), ACTION_HIGHLIGHT_RULE_DISABLE)
            danger(ACTION_HIGHLIGHT_RULE_DISABLE)
        }.show(binding.textMenuPosition) { action ->
            when (action) {
                ACTION_HIGHLIGHT_RULE_EDIT -> showDialogFragment(
                    HighlightRuleEditDialog.edit(ruleId)
                )

                ACTION_HIGHLIGHT_RULE_MANAGE -> startActivity<HighlightRuleActivity>()
                ACTION_HIGHLIGHT_RULE_DISABLE -> disableHighlightRule(ruleId)
            }
        }
    }

    private fun disableHighlightRule(ruleId: Long) {
        val rule = ReadBook.highlightRules.firstOrNull { it.id == ruleId }
            ?.copy(isEnabled = false) ?: return
        Coroutine.async(lifecycleScope) { appDb.highlightRuleDao.update(rule) }
            .onFinally { ReadBook.upHighlightRules() }
    }

    override fun currentHighlightStyle(): HighlightStyle {
        return editingHighlight?.styleObj() ?: HighlightStyle()
    }

    override fun onHighlightStyleChanged(style: HighlightStyle) {
        editingHighlight?.let { highlight ->
            ReadBook.updateHighlightStyle(highlight, style)
            ReadBook.saveLastHighlightStyle(style)
        }
    }

    override fun pickHighlightColor(dialogId: Int, initial: Int, withAlpha: Boolean) {
        val presets = if (withAlpha) HighlightColors.bg else HighlightColors.text
        ColorPickerDialog.newBuilder()
            .setColor(initial.takeIf { it != 0 } ?: presets.first())
            .setShowAlphaSlider(withAlpha)
            .setDialogType(ColorPickerDialog.TYPE_PRESETS)
            .setPresets(presets)
            .setDialogId(dialogId)
            .show(this)
    }

    private fun refreshHighlightStyleDialog() {
        highlightStyleDialog?.refresh()
        (supportFragmentManager.findFragmentByTag(HighlightStyleDialog::class.simpleName)
                as? HighlightStyleDialog)?.refresh()
    }

    /**
     * 当前选择的文本
     */
    override val hasHighlightFormatInSelection: Boolean
        get() = selectedHighlightsWithFormat().isNotEmpty()

    private fun selectedHighlightRange(): BookHighlight? {
        if (selectedText.isEmpty()) return null
        return binding.readView.curPage.createHighlight(HighlightStyle())
    }

    private fun clearSelectedHighlightFormat() {
        val selection = selectedHighlightRange() ?: return
        val titleLength = selection.layoutTitleLength.takeIf { it >= 0 } ?: return
        val chapter = binding.readView.curPage.textPage.getTextChapter()
        ReadBook.clearHighlightStyleInRange(
            chapter,
            titleLength,
            selection.bodyStart(titleLength),
            selection.bodyEnd(titleLength)
        )
    }

    private fun selectedHighlightsWithFormat(): List<BookHighlight> {
        val selection = selectedHighlightRange() ?: return emptyList()
        val chapter = binding.readView.curPage.textPage.getTextChapter()
        val titleLength = selection.layoutTitleLength.takeIf { it >= 0 } ?: return emptyList()
        val selectionStart = selection.bodyStart(titleLength)
        val selectionEnd = selection.bodyEnd(titleLength)
        return ReadBook.anchoredHighlightsOfChapter(chapter, titleLength)
            .filter { (highlight, anchor) ->
                anchor.start < selectionEnd && anchor.end > selectionStart &&
                        !highlight.styleObj().isEmpty
            }
            .map { it.first }
    }

    override val selectedText: String get() = binding.readView.getSelectText()

    /**
     * 文本选择菜单操作
     */
    override fun onMenuItemSelected(itemId: Int): Boolean {
        when (itemId) {
            R.id.menu_aloud_from_here -> lifecycleScope.launch {
                binding.readView.aloudStartSelect()
            }

            R.id.menu_aloud -> when (AppConfig.contentSelectSpeakMod) {
                1 -> lifecycleScope.launch {
                    binding.readView.aloudStartSelect()
                }

                else -> speak(binding.readView.getSelectText())
            }

            R.id.menu_bookmark -> binding.readView.curPage.let {
                val bookmark = it.createBookmark()
                if (bookmark == null) {
                    toastOnUi(R.string.create_bookmark_error)
                } else {
                    showDialogFragment(BookmarkDialog(bookmark))
                }
                return true
            }

            R.id.menu_highlight -> binding.readView.curPage.let {
                val style = visibleHighlightStyle(
                    GSON.fromJsonObject<HighlightStyle>(
                        getPrefString(PreferKey.highlightLastStyle)
                    ).getOrNull()
                )
                val anchorX = binding.textMenuPosition.x
                val anchorY = binding.textMenuPosition.y
                val highlight = it.createHighlight(style)
                if (highlight == null) {
                    toastOnUi(R.string.create_highlight_error)
                } else {
                    ReadBook.addHighlight(highlight)
                    binding.root.post {
                        showHighlightActionMenu(highlight, anchorX, anchorY)
                    }
                }
                return true
            }

            R.id.menu_clear_highlight_style -> {
                clearSelectedHighlightFormat()
                return true
            }

            R.id.menu_replace -> {
                val scopes = arrayListOf<String>()
                ReadBook.book?.name?.let {
                    scopes.add(it)
                }
                ReadBook.bookSource?.bookSourceUrl?.let {
                    scopes.add(it)
                }
                val text = selectedText.lineSequence().joinToString("\n") { it.trim() }
                replaceActivity.launch(
                    ReplaceEditActivity.startIntent(
                        this,
                        pattern = text,
                        scope = scopes.joinToString(";")
                    )
                )
                return true
            }

            R.id.menu_search_content -> {
                viewModel.searchContentQuery = selectedText
                openSearchActivity(selectedText)
                return true
            }

            R.id.menu_dict -> {
                showDialogFragment(DictDialog(selectedText))
                return true
            }
        }
        return false
    }

    /**
     * 文本选择菜单操作完成
     */
    override fun onMenuActionFinally() = binding.run {
        textActionMenu.dismiss()
        readView.cancelSelect()
    }

    override fun onEditTextActionMenu() {
        showTextSelectMenuConfig()
    }

    fun showTextSelectMenuConfig() {
        showDialogFragment(TextSelectMenuConfigDialog())
    }

    fun showReaderMenuConfig() {
        showDialogFragment(ReaderMenuConfigDialog())
    }

    fun refreshReaderMenu() {
        invalidateOptionsMenu()
    }

    private fun speak(text: String) {
        if (tts == null) {
            tts = TTS()
        }
        tts?.speak(text)
    }

    /**
     * 鼠标滚轮翻页
     */
    private fun mouseWheelPage(direction: PageDirection, distance: Float) {
        if (menuLayoutIsVisible || !AppConfig.mouseWheelPage) {
            return
        }
        if (binding.readView.isScroll) {
            // 滚动视图时滚动,否则翻页
            val scrollDistance = (distance * (AppConfig.mouseWheelScrollSpeed / 2f)).toInt()
            (binding.readView.pageDelegate as? ScrollPageDelegate)?.curPage?.scroll(scrollDistance)
        } else {
            keyPageDebounce(direction, mouseWheel = true, longPress = false)
        }
    }

    /**
     * 音量键翻页
     */
    private fun volumeKeyPage(direction: PageDirection, longPress: Boolean): Boolean {
        if (!AppConfig.volumeKeyPage) {
            return false
        }
        if (!AppConfig.volumeKeyPageOnPlay && BaseReadAloudService.isPlay()) {
            return false
        }
        handleKeyPage(direction, longPress)
        return true
    }

    private fun handleKeyPage(direction: PageDirection, longPress: Boolean) {
        if (AppConfig.keyPageOnLongPress || direction == PageDirection.NONE) {
            keyPage(direction)
        } else {
            keyPageDebounce(direction, longPress = longPress)
        }
    }

    private fun keyPageDebounce(
        direction: PageDirection,
        mouseWheel: Boolean = false,
        longPress: Boolean
    ) {
        if (longPress) {
            return
        }
        nextPageDebounce.apply {
            wait = if (mouseWheel) 200L else 600L
            leading = !mouseWheel
            trailing = mouseWheel
        }
        prevPageDebounce.apply {
            wait = if (mouseWheel) 200L else 600L
            leading = !mouseWheel
            trailing = mouseWheel
        }
        when (direction) {
            PageDirection.NEXT -> nextPageDebounce.invoke()
            PageDirection.PREV -> prevPageDebounce.invoke()
            else -> {}
        }
    }

    private fun keyPage(direction: PageDirection) {
        binding.readView.cancelTouchGestures()
        binding.readView.cancelSelect()
        binding.readView.pageDelegate?.isCancel = false
        binding.readView.pageDelegate?.keyTurnPage(direction)
    }

    override fun upMenuView() {
        handler.post {
            upMenu()
            binding.readMenu.upBookView()
        }
    }

    override fun loadChapterList(book: Book) {
        ReadBook.upMsg(getString(R.string.toc_updateing))
        viewModel.loadChapterList(book)
    }

    /**
     * 内容加载完成
     */
    override fun contentLoadFinish() {
        lifecycleScope.launch(Main.immediate) {
            if (ReadBook.book?.let { it.isEpub && it.readConfig?.epubUsePublisherLayout == true } == true) {
                openPublisherLayout(useNativePosition = false)
                return@launch
            }
            observeBookmarks()
            if (intent.getBooleanExtra("readAloud", false)) {
                intent.removeExtra("readAloud")
                ReadBook.readAloud()
            }
            loadStates = true
            loadReviewSummaryIfNeeded()
        }
    }

    /**
     * 更新内容
     */
    override fun upContent(
        relativePosition: Int,
        resetPageOffset: Boolean,
        readPositionVersion: Long?,
        success: (() -> Unit)?
    ) {
        lifecycleScope.launch {
            val shouldResetPageOffset = resetPageOffset &&
                (readPositionVersion == null || isReadPositionVersionCurrent(readPositionVersion))
            binding.readView.cancelTouchGestures()
            binding.readView.upContent(relativePosition, shouldResetPageOffset)
            scheduleAloudFollowCheck()
            observeBookmarks()
            upBookmarkIndicator()
            if (relativePosition == 0) {
                upSeekBarProgress()
            }
            loadStates = false
            loadReviewSummaryIfNeeded()
            success?.invoke()
        }
    }

    override fun readPositionVersion(): Long {
        return binding.readView.getReadPositionVersion()
    }

    override fun isReadPositionVersionCurrent(version: Long): Boolean {
        return binding.readView.getReadPositionVersion() == version
    }

    override suspend fun upContentAwait(
        relativePosition: Int,
        resetPageOffset: Boolean,
        readPositionVersion: Long?,
        success: (() -> Unit)?
    ) = withContext(Main.immediate) {
        val shouldResetPageOffset = resetPageOffset &&
            (readPositionVersion == null || isReadPositionVersionCurrent(readPositionVersion))
        binding.readView.cancelTouchGestures()
        binding.readView.upContent(relativePosition, shouldResetPageOffset)
        scheduleAloudFollowCheck()
        observeBookmarks()
        upBookmarkIndicator()
        if (relativePosition == 0) {
            upSeekBarProgress()
        }
        loadStates = false
        loadReviewSummaryIfNeeded()
    }

    override fun upPageAnim(upRecorder: Boolean) {
        lifecycleScope.launch {
            binding.readView.upPageAnim(upRecorder)
            upBookmarkIndicator()
        }
    }

    override fun notifyBookChanged() {
        bookChanged = true
        if (!ReadBook.inBookshelf) {
            viewModel.removeFromBookshelf { super.finish() }
        }
    }

    override fun cancelSelect() {
        runOnUiThread {
            binding.readView.cancelSelect()
        }
    }

    /**
     * 页面改变
     */
    override fun pageChanged() {
        pageChanged = true
        if (!isScroll) aloudControls.onMovement(100f)
        binding.readView.onPageChange()
        highlightPopup?.dismiss()
        handler.post {
            upBookmarkIndicator()
            upSeekBarProgress()
            restoreAloudFollowOnVisiblePage()
        }
        executor.execute {
            startBackupJob()
        }
    }

    override fun onReadScroll(offset: Int) {
        if (BaseReadAloudService.isRun && !isAutoPage) {
            ReadAloud.detachReadAloudFollow()
            aloudControls.onMovement(-offset * 100f / ChapterProvider.visibleHeight.coerceAtLeast(1))
            scheduleAloudFollowCheck()
        }
    }

    fun showReadAloudControls(resetPosition: Boolean = false) {
        aloudControls.reveal(resetPosition)
        scheduleAloudFollowCheck()
    }

    private fun scheduleAloudFollowCheck() {
        // Manual navigation emits detach before changing the displayed page.
        handler.removeCallbacks(restoreAloudFollowRunnable)
        handler.post(restoreAloudFollowRunnable)
    }

    private fun restoreAloudFollowOnVisiblePage() {
        if (!BaseReadAloudService.isRun || ReadAloud.followReadAloudPosition ||
            !getPrefBoolean(PreferKey.readAloudControlsRealtime, true)
        ) return
        val chapterStart = ReadAloud.readAloudChapterStart
        val chapterIndex = ReadAloud.readAloudChapterIndex
        if (chapterStart < 0 || chapterIndex != ReadBook.durChapterIndex) return
        val chapter = ReadBook.curTextChapter ?: return
        if (binding.readView.curPage.textPage !== chapter.getPage(ReadBook.durPageIndex)) return
        val (visibleChapter, line) = binding.readView.getReadAloudPos() ?: return
        if (visibleChapter != chapterIndex) return
        val speakingPage = chapter.getPageByReadPos(chapterStart) ?: return
        if (chapter.getPageByReadPos(line.chapterPosition) !== speakingPage) return
        ReadAloud.restoreReadAloudFollow()
        speakingPage.upPageAloudSpan(chapterStart - chapter.getReadLength(speakingPage.index))
        binding.readView.upContent(resetPageOffset = false)
    }

    /**
     * 更新进度条位置
     */
    private fun upSeekBarProgress() {
        val progress = when (AppConfig.progressBarBehavior) {
            "page" -> ReadBook.durPageIndex
            else /* chapter */ -> ReadBook.durChapterIndex
        }
        binding.readMenu.setSeekPage(progress)
    }

    /**
     * 显示菜单
     */
    override fun showMenuBar() {
        binding.readMenu.runMenuIn()
    }

    /**
     * 回到朗读位置：恢复页面跟随朗读，并精确跳到当前朗读位置。
     * 同章内直接定位到已记录的朗读字符位置；跨章时打开朗读所在章节并定位到该字符位置。
     * 全程不打断当前朗读。
     */
    override fun backToSpeakingPosition() {
        if (!BaseReadAloudService.isRun) return
        val speakingChapterIndex = ReadAloud.readAloudChapterIndex
        // 优先用观察到的进度; 回退到服务里存活的朗读位置(Activity 重建后进度事件可能尚未到达)
        val chapterStart = lastReadAloudChapterStart.takeIf {
            lastReadAloudChapterIndex == speakingChapterIndex && it >= 0
        }
            ?: ReadAloud.readAloudChapterStart
        when {
            speakingChapterIndex >= 0 && speakingChapterIndex != ReadBook.durChapterIndex -> {
                // 跨章：打开朗读所在章节并精确定位到朗读字符位置。
                // openChapter 会先脱离跟随, 故在加载完成回调里再恢复跟随。
                val durChapterPos = chapterStart.coerceAtLeast(0)
                val bookUrl = ReadBook.book?.bookUrl
                ReadBook.openChapter(speakingChapterIndex, durChapterPos) {
                    if (BaseReadAloudService.isRun && ReadBook.book?.bookUrl == bookUrl &&
                        ReadBook.durChapterIndex == speakingChapterIndex &&
                        ReadAloud.readAloudChapterIndex == speakingChapterIndex
                    ) {
                        ReadAloud.restoreReadAloudFollow()
                        upTextChapterAloudSpan(ReadAloud.readAloudChapterStart)
                    }
                }
            }

            else -> {
                ReadAloud.restoreReadAloudFollow()
                if (chapterStart >= 0) upTextChapterAloudSpan(chapterStart)
            }
        }
    }

    /**
     * 把显示页定位到章内字符位置并绘制朗读高亮。
     */
    private fun upTextChapterAloudSpan(chapterStart: Int) {
        if (chapterStart < 0) return
        val textChapter = ReadBook.curTextChapter ?: return
        lifecycleScope.launch(IO) {
            ReadBook.durChapterPos = chapterStart
            val pageIndex = ReadBook.durPageIndex
            val aloudSpanStart = chapterStart - textChapter.getReadLength(pageIndex)
            textChapter.getPage(pageIndex)?.upPageAloudSpan(aloudSpanStart)
            upContent()
        }
    }

    override val oldBook: Book?
        get() = ReadBook.book

    override fun changeTo(
        source: BookSource,
        book: Book,
        toc: List<BookChapter>,
        onSuccess: () -> Unit,
    ) {
        resetReviewSummaryState()
        if (!book.isAudio) {
            viewModel.changeTo(book, toc, onSuccess)
        } else {
            ReadAloud.stop(this)
            lifecycleScope.launch {
                withContext(IO) {
                    ReadBook.book?.migrateTo(book, toc)
                    book.removeType(BookType.updateError)
                    replaceBookAfterSourceChange(ReadBook.book, book, toc)
                }
                onSuccess()
                startActivityForBook(book)
                finish()
            }
        }
    }

    override fun replaceContent(content: String) {
        ReadBook.book?.let {
            viewModel.saveContent(it, content)
        }
    }

    override fun contentCached(chapterIndex: Int) {
        if (chapterIndex in ReadBook.durChapterIndex - 1..ReadBook.durChapterIndex + 1) {
            ReadBook.clearTextChapter()
            ReadBook.loadContent(resetPageOffset = false)
        }
    }

    override fun showActionMenu() {
        when {
            BaseReadAloudService.isRun -> showReadAloudDialog()
            isAutoPage -> showDialogFragment<AutoReadDialog>()
            isShowingSearchResult -> binding.searchMenu.runMenuIn()
            else -> binding.readMenu.runMenuIn()
        }
    }

    /**
     * 显示朗读菜单
     */
    override fun showReadAloudDialog() {
        showDialogFragment<ReadAloudDialog>()
    }

    /**
     * 自动翻页
     */
    override fun autoPage() {
        ReadAloud.stop(this)
        if (isAutoPage) {
            autoPageStop()
        } else {
            binding.readView.autoPager.start()
            binding.readMenu.setAutoPage(true)
            screenTimeOut = -1L
            screenOffTimerStart()
        }
    }

    override fun autoPageStop() {
        if (isAutoPage) {
            binding.readView.autoPager.stop()
            binding.readMenu.setAutoPage(false)
            dismissDialogFragment<AutoReadDialog>()
            upScreenTimeOut()
        }
    }

    override fun openSourceEditActivity() {
        ReadBook.bookSource?.let {
            sourceEditActivity.launch {
                putExtra("sourceUrl", it.bookSourceUrl)
            }
        }
    }

    override fun openBookInfoActivity() {
        ReadBook.book?.let {
            bookInfoActivity.launch {
                putExtra("name", it.name)
                putExtra("author", it.author)
            }
        }
    }

    /**
     * 替换
     */
    override fun openReplaceRule() {
        replaceActivity.launch(Intent(this, ReplaceRuleActivity::class.java))
    }

    /**
     * 打开目录
     */
    override fun openChapterList() {
        ReadBook.book?.let {
            tocActivity.launch(it.bookUrl)
        }
    }

    /**
     * 打开搜索界面
     */
    override fun openSearchActivity(searchWord: String?) {
        val book = ReadBook.book ?: return
        searchContentActivity.launch {
            putExtra("bookUrl", book.bookUrl)
            putExtra("searchWord", searchWord ?: viewModel.searchContentQuery)
            putExtra("searchResultIndex", viewModel.searchResultIndex)
            viewModel.searchResultList?.first()?.let {
                if (it.query == viewModel.searchContentQuery) {
                    IntentData.put("searchResultList", viewModel.searchResultList)
                }
            }
        }
    }

    /**
     * 禁用书源
     */
    override fun disableSource() {
        resetReviewSummaryState()
        viewModel.disableSource()
    }

    /**
     * 显示阅读样式配置
     */
    override fun showReadStyle() {
        showDialogFragment<ReadStyleDialog>()
    }

    /**
     * 显示更多设置
     */
    override fun showMoreSetting() {
        showDialogFragment<MoreConfigDialog>()
    }

    override fun showBookMemo() {
        ReadBook.book?.let { book ->
            showDialogFragment<io.legado.app.ui.widget.dialog.BookMemoDialog> {
                putString("bookUrl", book.bookUrl)
            }
        }
    }

    override fun showSearchSetting() {
        showDialogFragment<MoreConfigDialog>()
    }

    /**
     * 更新状态栏,导航栏
     */
    override fun upSystemUiVisibility() {
        upSystemUiVisibility(isInMultiWindow, !menuLayoutIsVisible, bottomDialog > 0)
        upNavigationBarColor()
    }

    // 退出全文搜索
    override fun exitSearchMenu() {
        if (isShowingSearchResult) {
            isShowingSearchResult = false
            binding.searchMenu.invalidate()
            binding.searchMenu.invisible()
            ReadBook.clearSearchResult()
            binding.readView.cancelSelect(true)
        }
    }

    /* 恢复到 全文搜索/进度条跳转前的位置 */
    private fun restoreLastBookProcess() {
        if (confirmRestoreProcess == true) {
            ReadBook.restoreLastBookProgress()
        } else if (confirmRestoreProcess == null) {
            alert(R.string.draw) {
                setMessage(R.string.restore_last_book_process)
                yesButton {
                    confirmRestoreProcess = true
                    ReadBook.restoreLastBookProgress() //恢复启动全文搜索前的进度
                }
                noButton {
                    ReadBook.lastBookProgress = null
                    confirmRestoreProcess = false
                }
                onCancelled {
                    ReadBook.lastBookProgress = null
                    confirmRestoreProcess = false
                }
            }
        }
    }

    override fun showLogin() {
        ReadBook.bookSource?.let {
            startActivity<SourceLoginActivity> {
                putExtra("bookType", BookType.text)
            }
        }
    }

    override fun payAction() {
        val book = ReadBook.book ?: return
        if (book.isLocal) return
        val chapter = appDb.bookChapterDao.getChapter(book.bookUrl, ReadBook.durChapterIndex)
        if (chapter == null) {
            toastOnUi("no chapter")
            return
        }
        alert(R.string.chapter_pay) {
            setMessage(chapter.title)
            yesButton {
                Coroutine.async(lifecycleScope) {
                    val source =
                        ReadBook.bookSource ?: throw NoStackTraceException("no book source")
                    val payAction = source.getContentRule().payAction
                    if (payAction.isNullOrBlank()) {
                        throw NoStackTraceException("no pay action")
                    }
                    val java = SourceLoginJsExtensions(this@ReadBookActivity, source, BookType.text)
                    runScriptWithContext {
                        source.evalJS(payAction) {
                            put("java", java)
                            put("book", book)
                            put("chapter", chapter)
                            put("title", chapter.title)
                            put("baseUrl", chapter.url)
                            put("result", null)
                            put("src", null)
                        }.toString()
                    }
                }.onSuccess(IO) {
                    if (it.isAbsUrl()) {
                        startActivity<WebViewActivity> {
                            val bookSource = ReadBook.bookSource
                            putExtra("title", getString(R.string.chapter_pay))
                            putExtra("url", it)
                            putExtra("sourceOrigin", bookSource?.bookSourceUrl)
                            putExtra("sourceName", bookSource?.bookSourceName)
                            putExtra("sourceType", bookSource?.getSourceType())
                        }
                    } else if (it.isTrue()) {
                        //购买成功后刷新目录
                        ReadBook.book?.let {
                            ReadBook.curTextChapter = null
                            BookHelp.delContent(book, chapter)
                            loadChapterList(book)
                        }
                    }
                }.onError {
                    AppLog.put("执行购买操作出错\n${it.localizedMessage}", it, true)
                }
            }
            noButton()
        }
    }

    /**
     * 点击图片
     */
    override fun oldClickImg(src: String): Boolean {
        val urlMatcher = paramPattern.matcher(src)
        if (urlMatcher.find()) {
            val urlOptionStr = src.substring(urlMatcher.end())
            val urlOptionMap = GSON.fromJsonObject<Map<String, String>>(urlOptionStr).getOrNull()
            val click = urlOptionMap?.get("click")
            if (click != null) {
                Coroutine.async(lifecycleScope,IO) {
                    val source = ReadBook.bookSource ?: return@async
                    val java = SourceLoginJsExtensions(this@ReadBookActivity, source, BookType.text)
                    val book = ReadBook.book ?: return@async
                    val chapter = appDb.bookChapterDao.getChapter(book.bookUrl, ReadBook.durChapterIndex) ?: throw Exception("no find chapter")
                    runScriptWithContext {
                        source.evalJS(click) {
                            put("java", java)
                            put("book", book)
                            put("chapter", chapter)
                            put("result", src)
                        }
                    }
                }.onError {
                    AppLog.put("执行图片链接click键值出错\n${it.localizedMessage}", it, true)
                }
                return true
            }
            val jsStr = urlOptionMap?.get("js") ?: return false
            Coroutine.async(lifecycleScope, IO) {
                val source = ReadBook.bookSource ?: return@async
                val book = ReadBook.book ?: return@async
                val chapter = appDb.bookChapterDao.getChapter(book.bookUrl, ReadBook.durChapterIndex) ?: throw Exception("no find chapter")
                val urlNoOption = src.take(urlMatcher.start())
                AnalyzeRule(book, source).apply {
                    setCoroutineContext(coroutineContext)
                    setBaseUrl(chapter.url)
                    setChapter(chapter)
                    evalJS(jsStr, urlNoOption)
                }
            }.onError {
                AppLog.put("执行图片链接js键值出错\n${it.localizedMessage}", it, true)
            }
            return true
        }
        return false
    }

    override fun clickImg(click: String, src: String) {
        Coroutine.async(lifecycleScope,IO) {
            val source = ReadBook.bookSource ?: return@async
            val java = SourceLoginJsExtensions(this@ReadBookActivity, source, BookType.text)
            val book = ReadBook.book ?: return@async
            val chapter = appDb.bookChapterDao.getChapter(book.bookUrl, ReadBook.durChapterIndex) ?: throw Exception("no find chapter")
            runScriptWithContext {
                source.evalJS(click) {
                    put("java", java)
                    put("book", book)
                    put("chapter", chapter)
                    put("result", src)
                }
            }
        }.onError {
            AppLog.put("执行图片链接click键值出错\n${it.localizedMessage}", it, true)
        }
    }

    override fun onReviewClick(paragraphNum: Int, count: Int, chapterIndex: Int) {
        if (paragraphNum != -1 && paragraphNum <= 0) return
        if (count <= 0) {
            toastOnUi(R.string.review_empty)
            return
        }
        val source = ReadBook.bookSource ?: return
        val reviewDialogTag = ReviewDetailDialog::class.simpleName
        val fragmentManager = supportFragmentManager
        fun showReviewDialog(dialog: ReviewDetailDialog) {
            val now = SystemClock.uptimeMillis()
            val taggedDialog = fragmentManager.findFragmentByTag(reviewDialogTag)
            val existingDialog = taggedDialog != null || fragmentManager.fragments.any {
                it is ReviewDetailDialog && !it.isRemoving
            }
            if (fragmentManager.isStateSaved || existingDialog ||
                now - lastReviewDialogRequestAt < REVIEW_DIALOG_REQUEST_COOLDOWN_MS
            ) return
            lastReviewDialogRequestAt = now
            dialog.showNow(fragmentManager, reviewDialogTag)
        }
        if (source.isJsSource()) {
            val book = ReadBook.book ?: return
            showReviewDialog(
                ReviewDetailDialog(
                    paragraphNum = paragraphNum,
                    totalCount = count,
                    chapterIndex = chapterIndex,
                    paragraphData = ChapterProvider.getReviewKeyById(paragraphNum, chapterIndex),
                    bookUrl = book.bookUrl,
                    sourceKey = source.getKey(),
                    ruleHash = source.mainJs.hashCode(),
                )
            )
            return
        }
        val rule = source.ruleReview ?: run {
            toastOnUi(R.string.review_rule_missing)
            return
        }
        if (!rule.enabled) {
            toastOnUi(R.string.review_rule_missing)
            return
        }
        if (rule.reviewDetailUrl.isNullOrBlank()) {
            toastOnUi(R.string.review_detail_url_missing)
            return
        }
        if (rule.detailListRule.isNullOrBlank() || rule.detailContentRule.isNullOrBlank()) {
            toastOnUi(R.string.review_detail_rule_missing)
            return
        }
        val book = ReadBook.book ?: return
        showReviewDialog(
            ReviewDetailDialog(
                paragraphNum = paragraphNum,
                totalCount = count,
                chapterIndex = chapterIndex,
                paragraphData = ChapterProvider.getReviewKeyById(paragraphNum, chapterIndex),
                bookUrl = book.bookUrl,
                sourceKey = source.getKey(),
                ruleHash = rule.hashCode()
            )
        )
    }

    private fun loadReviewSummaryIfNeeded() {
        val source = ReadBook.bookSource ?: run {
            clearReviewSummaryProviders()
            return
        }
        val book = ReadBook.book ?: run {
            clearReviewSummaryProviders()
            return
        }
        val chapterIndex = ReadBook.durChapterIndex
        val textChapter = ReadBook.curTextChapter
        if (textChapter != null &&
            textChapter.chapter.index == chapterIndex &&
            !textChapter.hasBodyContent
        ) {
            clearReviewSummaryProviders()
            return
        }

        if (source.isJsSource()) {
            loadJsReviewSummaryIfNeeded(book, source, chapterIndex)
            return
        }
        val rule = source.ruleReview ?: run {
            clearReviewSummaryProviders()
            return
        }
        val summaryUrl = rule.configuredSummaryUrl()
        if (summaryUrl == null) {
            clearReviewSummaryProviders()
            return
        }

        val key = buildReviewSummaryKey(book, source, rule.hashCode(), chapterIndex)
        if (reviewSummaryAppliedKey == key || reviewSummaryLoadingKey == key) return
        synchronized(reviewSummaryCache) { reviewSummaryCache[key] }?.let { cached ->
            applyReviewSummary(key, chapterIndex, cached)
            prefetchAdjacentReviewSummary(book, source, rule, chapterIndex)
            return
        }

        reviewSummaryLoadingKey = key
        val requestToken = ++reviewSummaryRequestToken
        if (reviewSummaryAppliedKey != key) {
            ChapterProvider.clearReviewProviders()
        }
        Coroutine.async(lifecycleScope, IO) {
            val chapter = appDb.bookChapterDao.getChapter(book.bookUrl, chapterIndex)
                ?: return@async null
            if (chapter.isVolume) return@async null
            val analyzeUrl = AnalyzeUrl(
                summaryUrl,
                baseUrl = chapter.url,
                source = source,
                ruleData = book,
                chapter = chapter,
                coroutineContext = coroutineContext
            )
            val body = analyzeUrl.getStrResponseAwait(useWebView = false).body
                ?: return@async null
            ReviewRuleParser.parseSummary(
                body,
                rule,
                source,
                book,
                chapter,
                analyzeUrl.url,
                coroutineContext
            )
        }.onSuccess(Main) { result ->
            releaseReviewSummaryLoadingKey(key)
            if (requestToken != reviewSummaryRequestToken) return@onSuccess
            val currentBook = ReadBook.book ?: return@onSuccess
            val currentSource = ReadBook.bookSource ?: return@onSuccess
            val currentRule = currentSource.ruleReview ?: return@onSuccess
            val currentKey = buildReviewSummaryKey(
                currentBook,
                currentSource,
                currentRule.hashCode(),
                ReadBook.durChapterIndex
            )
            if (currentKey != key) return@onSuccess
            if (result == null) {
                ChapterProvider.clearReviewProviders()
                return@onSuccess
            }
            synchronized(reviewSummaryCache) {
                reviewSummaryCache[key] = result
            }
            applyReviewSummary(key, chapterIndex, result)
            prefetchAdjacentReviewSummary(book, source, rule, chapterIndex)
        }.onError {
            releaseReviewSummaryLoadingKey(key)
            if (requestToken != reviewSummaryRequestToken) return@onError
            val currentBook = ReadBook.book ?: return@onError
            val currentSource = ReadBook.bookSource ?: return@onError
            val currentRule = currentSource.ruleReview ?: return@onError
            if (buildReviewSummaryKey(
                    currentBook,
                    currentSource,
                    currentRule.hashCode(),
                    ReadBook.durChapterIndex
                ) != key
            ) return@onError
            ChapterProvider.clearReviewProviders()
            AppLog.put("加载段评统计出错\n${it.localizedMessage}", it)
        }
    }

    private fun loadJsReviewSummaryIfNeeded(
        book: Book,
        source: BookSource,
        chapterIndex: Int,
    ) {
        val sourceHash = source.mainJs.hashCode()
        val key = buildReviewSummaryKey(book, source, sourceHash, chapterIndex)
        if (reviewSummaryAppliedKey == key || reviewSummaryLoadingKey == key) return
        synchronized(reviewSummaryCache) { reviewSummaryCache[key] }?.let { cached ->
            applyReviewSummary(key, chapterIndex, cached)
            return
        }

        reviewSummaryLoadingKey = key
        val requestToken = ++reviewSummaryRequestToken
        if (reviewSummaryAppliedKey != key) {
            ChapterProvider.clearReviewProviders()
        }
        Coroutine.async(lifecycleScope, IO) {
            val chapter = appDb.bookChapterDao.getChapter(book.bookUrl, chapterIndex)
                ?: return@async null
            if (chapter.isVolume) return@async null
            JsSourceReview.getReviewSummaryAwait(source, book, chapter)
        }.onSuccess(Main) { result ->
            releaseReviewSummaryLoadingKey(key)
            if (requestToken != reviewSummaryRequestToken) return@onSuccess
            val currentBook = ReadBook.book ?: return@onSuccess
            val currentSource = ReadBook.bookSource ?: return@onSuccess
            if (!currentSource.isJsSource()) return@onSuccess
            val currentKey = buildReviewSummaryKey(
                currentBook,
                currentSource,
                currentSource.mainJs.hashCode(),
                ReadBook.durChapterIndex,
            )
            if (currentKey != key) return@onSuccess
            if (result == null) {
                reviewSummaryAppliedKey = key
                ChapterProvider.clearReviewProviders()
                return@onSuccess
            }
            synchronized(reviewSummaryCache) {
                reviewSummaryCache[key] = result
            }
            applyReviewSummary(key, chapterIndex, result)
        }.onError {
            releaseReviewSummaryLoadingKey(key)
            if (requestToken != reviewSummaryRequestToken) return@onError
            val currentBook = ReadBook.book ?: return@onError
            val currentSource = ReadBook.bookSource ?: return@onError
            if (!currentSource.isJsSource()) return@onError
            if (buildReviewSummaryKey(
                    currentBook,
                    currentSource,
                    currentSource.mainJs.hashCode(),
                    ReadBook.durChapterIndex,
                ) != key
            ) return@onError
            ChapterProvider.clearReviewProviders()
            AppLog.put("加载 JavaScript 段评统计出错\n${it.localizedMessage}", it)
        }
    }

    private fun clearReviewSummaryProviders() {
        reviewSummaryRequestToken++
        reviewSummaryAppliedKey = null
        reviewSummaryLoadingKey = null
        ChapterProvider.clearReviewProviders()
    }

    private fun applyReviewSummary(
        key: String,
        chapterIndex: Int,
        result: ReviewRuleParser.SummaryResult
    ) {
        ChapterProvider.setReviewProviders(
            countProvider = { targetChapterIndex, reviewId ->
                if (targetChapterIndex == chapterIndex) result.counts[reviewId] ?: 0 else 0
            },
            keyProvider = { targetChapterIndex, reviewId ->
                if (targetChapterIndex == chapterIndex) result.keys[reviewId] else null
            },
            chapterIndex = chapterIndex,
        )
        reviewSummaryAppliedKey = key
        binding.readView.upContent(relativePosition = 0, resetPageOffset = false)
    }

    private fun prefetchAdjacentReviewSummary(
        book: Book,
        source: BaseSource,
        rule: ReviewRule,
        chapterIndex: Int
    ) {
        val maxIndex = if (ReadBook.simulatedChapterSize > 0) {
            ReadBook.simulatedChapterSize
        } else {
            ReadBook.chapterSize
        }
        if (maxIndex <= 0) return

        val requestToken = reviewSummaryRequestToken
        for (targetIndex in intArrayOf(chapterIndex - 1, chapterIndex + 1)) {
            if (targetIndex !in 0 until maxIndex) continue
            val loadedChapter = sequenceOf(
                ReadBook.prevTextChapter,
                ReadBook.curTextChapter,
                ReadBook.nextTextChapter
            ).filterNotNull().firstOrNull { it.chapter.index == targetIndex }
            if (loadedChapter == null || !loadedChapter.hasBodyContent) continue

            val key = buildReviewSummaryKey(book, source, rule.hashCode(), targetIndex)
            if (reviewSummaryLoadingKey == key) continue
            if (synchronized(reviewSummaryCache) { reviewSummaryCache.containsKey(key) }) continue
            val shouldPrefetch = synchronized(reviewSummaryPrefetchingKeys) {
                reviewSummaryPrefetchingKeys.add(key)
            }
            if (!shouldPrefetch) continue

            Coroutine.async(lifecycleScope, IO) {
                val chapter = appDb.bookChapterDao.getChapter(book.bookUrl, targetIndex)
                    ?: return@async null
                if (chapter.isVolume) return@async null
                val summaryUrl = rule.reviewSummaryUrl?.takeIf { it.isNotBlank() }
                    ?: return@async null
                val analyzeUrl = AnalyzeUrl(
                    summaryUrl,
                    baseUrl = chapter.url,
                    source = source,
                    ruleData = book,
                    chapter = chapter,
                    coroutineContext = coroutineContext
                )
                val body = analyzeUrl.getStrResponseAwait(useWebView = false).body
                    ?: return@async null
                ReviewRuleParser.parseSummary(
                    body,
                    rule,
                    source,
                    book,
                    chapter,
                    analyzeUrl.url,
                    coroutineContext
                )
            }.onSuccess(Main) { result ->
                synchronized(reviewSummaryPrefetchingKeys) {
                    reviewSummaryPrefetchingKeys.remove(key)
                }
                if (requestToken != reviewSummaryRequestToken || result == null) return@onSuccess
                synchronized(reviewSummaryCache) {
                    reviewSummaryCache[key] = result
                }
            }.onError {
                synchronized(reviewSummaryPrefetchingKeys) {
                    reviewSummaryPrefetchingKeys.remove(key)
                }
            }
        }
    }

    private fun buildReviewSummaryKey(
        book: Book,
        source: BaseSource,
        reviewHash: Int,
        chapterIndex: Int
    ): String = "${source.getKey()}|${book.bookUrl}|$reviewHash#$chapterIndex"

    private fun releaseReviewSummaryLoadingKey(key: String) {
        if (reviewSummaryLoadingKey == key) {
            reviewSummaryLoadingKey = null
        }
    }


    /**
     * 朗读按钮
     */
    override fun onClickReadAloud() {
        autoPageStop()
        when {
            !BaseReadAloudService.isRun -> {
                ReadAloud.upReadAloudClass()
                val scrollPageAnim = ReadBook.pageAnim() == 3
                if (scrollPageAnim) {
                    val pos = binding.readView.getReadAloudPos()
                    if (pos != null) {
                        val (index, line) = pos
                        if (ReadBook.durChapterIndex != index) {
                            ReadBook.openChapter(index, line.chapterPosition, false) {
                                ReadBook.readAloud(
                                    startPos = line.pagePosition,
                                    rewindToSentenceStart = AppConfig.readAloudStartAtSentence
                                )
                            }
                        } else {
                            ReadBook.durChapterPos = line.chapterPosition
                            ReadBook.readAloud(
                                startPos = line.pagePosition,
                                rewindToSentenceStart = AppConfig.readAloudStartAtSentence
                            )
                        }
                    } else {
                        ReadBook.readAloud(rewindToSentenceStart = AppConfig.readAloudStartAtSentence)
                    }
                } else {
                    ReadBook.readAloud(rewindToSentenceStart = AppConfig.readAloudStartAtSentence)
                }
            }

            BaseReadAloudService.pause -> {
                val scrollPageAnim = ReadBook.pageAnim() == 3
                if (scrollPageAnim && pageChanged) {
                    pageChanged = false
                    val pos = binding.readView.getReadAloudPos()
                    if (pos != null) {
                        val (index, line) = pos
                        if (ReadBook.durChapterIndex != index) {
                            ReadBook.openChapter(index, line.chapterPosition, false) {
                                ReadBook.readAloud(
                                    startPos = line.pagePosition,
                                    rewindToSentenceStart = AppConfig.readAloudStartAtSentence
                                )
                            }
                        } else {
                            ReadBook.durChapterPos = line.chapterPosition
                            ReadBook.readAloud(
                                startPos = line.pagePosition,
                                rewindToSentenceStart = AppConfig.readAloudStartAtSentence
                            )
                        }
                    } else {
                        ReadBook.readAloud(rewindToSentenceStart = AppConfig.readAloudStartAtSentence)
                    }
                } else {
                    ReadAloud.resume(this)
                }
            }

            else -> ReadAloud.pause(this)
        }
    }

    override fun showHelp() {
        showHelp("readMenuHelp")
    }

    /**
     * 长按图片
     */
    @SuppressLint("RtlHardcoded")
    override fun onImageLongPress(x: Float, y: Float, src: String) {
        popupAction.setItems(
            listOf(
                SelectItem(getString(R.string.show), "show"),
                SelectItem(getString(R.string.refresh), "refresh"),
                SelectItem(getString(R.string.action_save), "save"),
                SelectItem(getString(R.string.menu), "menu"),
                SelectItem(getString(R.string.select_folder), "selectFolder")
            )
        )
        popupAction.onActionClick = {
            when (it) {
                "show" -> showDialogFragment(PhotoDialog(src, isBook = true))
                "refresh" -> viewModel.refreshImage(src)
                "save" -> {
                    val path = ACache.get().getAsString(AppConst.imagePathKey)
                    if (path.isNullOrEmpty()) {
                        selectImageDir.launch {
                            value = src
                        }
                    } else {
                        viewModel.saveImage(src, path.toUri())
                    }
                }

                "menu" -> showActionMenu()
                "selectFolder" -> selectImageDir.launch()
            }
            popupAction.dismiss()
        }
        popupAction.showAtLocation(
            binding.readView, Gravity.BOTTOM or Gravity.LEFT, x.toInt(),
            binding.root.rootView.height - y.toInt()
        )
    }

    /**
     * colorSelectDialog
     */
    override fun onColorSelected(dialogId: Int, color: Int) = ReadBookConfig.durConfig.run {
        when (dialogId) {
            TEXT_COLOR -> {
                setCurTextColor(color)
                postEvent(EventBus.UP_CONFIG, arrayListOf(2, 6, 9, 11))
                if (AppConfig.readBarStyleFollowPage) {
                    postEvent(EventBus.UPDATE_READ_ACTION_BAR, true)
                }
            }

            TEXT_ACCENT_COLOR -> {
                setCurTextAccentColor(color)
                postEvent(EventBus.UP_CONFIG, arrayListOf(2, 6, 9, 11))
                if (AppConfig.readBarStyleFollowPage) {
                    postEvent(EventBus.UPDATE_READ_ACTION_BAR, true)
                }
            }

            BG_COLOR -> {
                setCurBg(0, "#${color.hexString}")
                postEvent(EventBus.UP_CONFIG, arrayListOf(1))
                if (AppConfig.readBarStyleFollowPage) {
                    postEvent(EventBus.UPDATE_READ_ACTION_BAR, true)
                }
            }

            REVIEW_ICON_COLOR -> {
                ReadBookConfig.reviewIconColor = color
                postEvent(EventBus.UP_CONFIG, arrayListOf(8, 9, 11))
            }

            UNDERLINE_COLOR -> {
                ReadBookConfig.underlineColor = color
                postEvent(EventBus.UP_CONFIG, arrayListOf(6, 9, 11))
            }

            HighlightStyleDialog.HL_FILL,
            HighlightStyleDialog.HL_TEXT,
            HighlightStyleDialog.HL_UNDERLINE,
            HighlightStyleDialog.HL_STRIKE,
            HighlightStyleDialog.HL_BOX,
            HighlightStyleDialog.HL_EMPHASIS,
            HighlightStyleDialog.HL_SHADOW -> {
                val style = HighlightStyleDialog.applyChannelColor(
                    currentHighlightStyle(),
                    dialogId,
                    color
                )
                onHighlightStyleChanged(style)
                refreshHighlightStyleDialog()
            }

            TIP_COLOR -> {
                ReadTipConfig.tipColor = color
                postEvent(EventBus.TIP_COLOR, "")
                postEvent(EventBus.UP_CONFIG, arrayListOf(2))
            }

            TIP_DIVIDER_COLOR -> {
                ReadTipConfig.tipDividerColor = color
                postEvent(EventBus.TIP_COLOR, "")
                postEvent(EventBus.UP_CONFIG, arrayListOf(2))
            }

            TITLE_NUMBER_COLOR -> {
                ReadBookConfig.titleNumberColor = color
                postEvent(EventBus.TIP_COLOR, "")
                postEvent(EventBus.UP_CONFIG, arrayListOf(8, 5))
            }

            TITLE_COLOR -> {
                ReadBookConfig.titleColor = color
                postEvent(EventBus.TIP_COLOR, "")
                postEvent(EventBus.UP_CONFIG, arrayListOf(8, 5))
            }
        }
    }

    /**
     * colorSelectDialog
     */
    override fun onDialogDismissed(dialogId: Int) = Unit

    override fun onTocRegexDialogResult(tocRegex: String) {
        ReadBook.book?.let {
            it.tocUrl = tocRegex
            loadChapterList(it)
        }
    }

    private fun sureSyncProgress(progress: BookProgress) {
        alert(R.string.get_book_progress) {
            setMessage(R.string.current_progress_exceeds_cloud)
            okButton {
                ReadBook.setProgress(progress)
            }
            noButton()
        }
    }

    /* 进度条跳转到指定章节 */
    override fun skipToChapter(index: Int) {
        ReadBook.saveCurrentBookProgress() //退出章节跳转恢复此时进度
        viewModel.openChapter(index)
    }

    /* 全文搜索跳转 */
    override fun navigateToSearch(searchResult: SearchResult, index: Int) {
        viewModel.searchResultIndex = index
        skipToSearch(searchResult)
    }

    override fun onMenuShow() {
        binding.readView.autoPager.pause()
        updateReadAloudFloatBar(menuShowing = true)
    }

    override fun onMenuHide() {
        binding.readView.autoPager.resume()
        aloudControls.reveal()
        updateReadAloudFloatBar(menuHiding = true)
    }

    private fun updateReadAloudFloatBar(
        menuShowing: Boolean = false,
        menuHiding: Boolean = false,
    ) {
        val menuVisible = when {
            menuShowing -> true
            menuHiding -> bottomDialog > 0 || binding.searchMenu.bottomMenuVisible
            else -> menuLayoutIsVisible
        }
        aloudControls.update(menuVisible)
    }

    override fun onLayoutPageCompleted(index: Int, page: TextPage) {
        upSeekBarThrottle.invoke()
        binding.readView.onLayoutPageCompleted(index, page)
    }

    /* 全文搜索跳转 */
    private fun skipToSearch(searchResult: SearchResult) {
        if (searchResult.chapterIndex != ReadBook.durChapterIndex) {
            viewModel.openChapter(searchResult.chapterIndex) {
                jumpToPosition(searchResult)
            }
        } else {
            jumpToPosition(searchResult)
        }
    }

    private fun jumpToPosition(searchResult: SearchResult) {
        val curTextChapter = ReadBook.curTextChapter ?: return
        binding.searchMenu.updateSearchInfo()
        val searchResultPositions =
            viewModel.searchResultPositions(curTextChapter, searchResult)
        val (pageIndex, lineIndex, charIndex, addLine, charIndex2) = searchResultPositions
        ReadBook.skipToPage(pageIndex) {
            isSelectingSearchResult = true
            binding.readView.curPage.selectStartMoveIndex(0, lineIndex, charIndex)
            when (addLine) {
                0 -> binding.readView.curPage.selectEndMoveIndex(
                    0,
                    lineIndex,
                    charIndex + searchResultPositions[5] - 1
                )

                1 -> binding.readView.curPage.selectEndMoveIndex(
                    0, lineIndex + 1, charIndex2
                )
                //consider change page, jump to scroll position
                -1 -> binding.readView.curPage.selectEndMoveIndex(1, 0, charIndex2)
            }
            binding.readView.isTextSelected = true
            isSelectingSearchResult = false
        }
    }

    override fun addBookmark() {
        val book = ReadBook.book
        val page = ReadBook.curTextChapter?.getPage(ReadBook.durPageIndex)
        if (book != null && page != null) {
            val bookmark = book.createBookMark().apply {
                chapterIndex = ReadBook.durChapterIndex
                chapterPos = ReadBook.durChapterPos
                chapterName = page.title
                bookText = page.text.trim()
            }
            showDialogFragment(BookmarkDialog(bookmark))
        }
    }

    override fun toggleBookmark() {
        if (bookmarkTogglePending) return
        val book = ReadBook.book ?: return
        val page = binding.readView.curPage.textPage
        if (page.lines.isEmpty()) {
            toastOnUi(R.string.create_bookmark_error)
            return
        }
        val pageStart = page.chapterPosition
        val pageEnd = pageStart + page.charSize
        bookmarkTogglePending = true
        lifecycleScope.launch {
            var awaitingConfirmation = false
            try {
                val confirmDelete = bookmarkToggleMutex.withLock {
                    val pageBookmarks = withContext(IO) {
                        appDb.bookmarkDao.getByBook(book.name, book.author).filter {
                            it.chapterIndex == page.chapterIndex && it.chapterPos in pageStart..<pageEnd
                        }
                    }
                    when {
                        pageBookmarks.size > 1 -> pageBookmarks
                        pageBookmarks.isNotEmpty() -> {
                            deleteBookmarks(pageBookmarks)
                            null
                        }

                        else -> {
                            val bookmark = book.createBookMark().apply {
                                chapterIndex = page.chapterIndex
                                chapterPos = pageStart
                                chapterName = page.title
                                bookText = page.text.trim()
                            }
                            withContext(IO) {
                                appDb.bookmarkDao.insert(bookmark)
                            }
                            toastOnUi(R.string.bookmark_added)
                            null
                        }
                    }
                }
                confirmDelete?.let { pageBookmarks ->
                    var deleteConfirmed = false
                    alert(titleResource = R.string.bookmark) {
                        setMessage(getString(R.string.delete_page_bookmarks, pageBookmarks.size))
                        okButton {
                            deleteConfirmed = true
                            lifecycleScope.launch {
                                try {
                                    bookmarkToggleMutex.withLock {
                                        deleteBookmarks(pageBookmarks)
                                    }
                                } finally {
                                    bookmarkTogglePending = false
                                }
                            }
                        }
                        noButton()
                        onDismiss {
                            if (!deleteConfirmed) {
                                bookmarkTogglePending = false
                            }
                        }
                    }
                    awaitingConfirmation = true
                }
            } finally {
                if (!awaitingConfirmation) {
                    bookmarkTogglePending = false
                }
            }
        }
    }

    private suspend fun deleteBookmarks(pageBookmarks: List<Bookmark>) {
        withContext(IO) {
            appDb.bookmarkDao.delete(*pageBookmarks.toTypedArray())
        }
        toastOnUi(R.string.bookmark_removed)
    }

    private fun observeBookmarks() {
        val book = ReadBook.book ?: return
        val bookKey = book.name to book.author
        if (bookmarkBookKey == bookKey) return
        bookmarkJob?.cancel()
        bookmarkBookKey = bookKey
        bookmarks = emptyList()
        bookmarkJob = lifecycleScope.launch {
            appDb.bookmarkDao.flowByBook(book.name, book.author).collect {
                bookmarks = it
                upBookmarkIndicator()
            }
        }
    }

    private fun resetBookmarkObserver() {
        bookmarkJob?.cancel()
        bookmarkJob = null
        bookmarkBookKey = null
        bookmarks = emptyList()
        binding.readView.curPage.showBookmarkIndicator(false)
    }

    fun upBookmarkIndicator() {
        val pageView = binding.readView.curPage
        val textPage = pageView.textPage
        val hasBookmark = textPage.lines.isNotEmpty() && bookmarks.any {
            it.chapterIndex == textPage.chapterIndex && textPage.containPos(it.chapterPos)
        }
        val showIndicator = AppConfig.pullToToggleBookmark &&
                !binding.readView.isScroll && hasBookmark
        pageView.showBookmarkIndicator(showIndicator)
    }

    override fun changeReplaceRuleState() {
        ReadBook.book?.let {
            it.setUseReplaceRule(!it.getUseReplaceRule())
            ReadBook.saveRead()
            menu?.findItem(R.id.menu_enable_replace)?.isChecked = it.getUseReplaceRule()
            viewModel.replaceRuleChanged()
        }
    }

    override fun setReplacePreview(enabled: Boolean) {
        val generation = ++replacePreviewGeneration
        replacePreviewJob?.cancel()
        replacePreviewJob = null
        if (!enabled) return
        val sourcePosition = binding.readView.getReadPosition()
            ?.takeIf { it.first == ReadBook.durChapterIndex }
            ?.second?.chapterPosition
            ?: ReadBook.durChapterPos
        replacePreviewJob = lifecycleScope.launch {
            val preview = try {
                ReadBook.buildReplacePreview(sourcePosition)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                AppLog.put("生成替换净化预览失败\n${e.localizedMessage}", e)
                null
            } ?: return@launch
            if (generation != replacePreviewGeneration ||
                !binding.readView.showReplacePreview(preview)
            ) {
                preview.previewChapter.cancelLayout()
            }
        }
    }

    private fun startBackupJob() {
        backupJob?.cancel()
        backupJob = lifecycleScope.launch(IO) {
            delay(300000)
            ReadBook.book?.let {
                AppWebDav.uploadBookProgress(it)
                ensureActive()
                it.update()
                Backup.autoBack(this@ReadBookActivity)
            }
        }
    }

    override fun sureNewProgress(progress: BookProgress) {
        syncDialog?.dismiss()
        syncDialog = alert(R.string.get_book_progress) {
            setMessage(R.string.cloud_progress_exceeds_current)
            okButton {
                ReadAloud.detachReadAloudFollow()
                ReadBook.setProgress(progress)
            }
            noButton()
        }
    }

    override fun finish() {
        val book = ReadBook.book ?: return super.finish()
        if (ReadBook.inBookshelf) {
            callBackBookEnd()
            return super.finish()
        }
        if (!AppConfig.showAddToShelfAlert) {
            callBackBookEnd()
            viewModel.removeFromBookshelf { super.finish() }
        } else {
            alert(title = getString(R.string.add_to_bookshelf)) {
                setMessage(getString(R.string.check_add_bookshelf, book.name))
                okButton {
                    ReadBook.book?.removeType(BookType.notShelf)
                    ReadBook.book?.save()
                    SourceCallBack.callBackBook(SourceCallBack.ADD_BOOK_SHELF, ReadBook.bookSource, ReadBook.book)
                    ReadBook.inBookshelf = true
                    setResult(RESULT_OK)
                }
                noButton {
                    callBackBookEnd()
                    viewModel.removeFromBookshelf { super.finish() }
                }
            }
        }
    }

    private fun callBackBookEnd() {
        SourceCallBack.callBackBook(SourceCallBack.END_READ, ReadBook.bookSource, ReadBook.book, ReadBook.curTextChapter?.chapter)
    }

    override fun onDestroy() {
        super.onDestroy()
        aloudControls.dispose()
        tts?.clearTts()
        textActionMenu.dismiss()
        popupAction.dismiss()
        readerOverflowPopup?.dismiss()
        highlightPopup?.dismiss()
        binding.readView.onDestroy()
        val wasCurrentReader = ReadBook.unregister(this)
        handler.removeCallbacksAndMessages(null) // 清理Handler消息
        if (wasCurrentReader && !ReadBook.inBookshelf && !isChangingConfigurations && !openingPublisherLayout) {
            viewModel.removeFromBookshelf(null)
        }
        if (!BuildConfig.DEBUG) {
            Backup.autoBack(this)
        }
    }

    override fun observeLiveBus() = binding.run {
        observeEvent<String>(EventBus.TIME_CHANGED) { readView.upTime() }
        observeEvent<Int>(EventBus.BATTERY_CHANGED) { readView.upBattery(it) }
        observeEvent<Boolean>(EventBus.MEDIA_BUTTON) {
            if (it) {
                onClickReadAloud()
            } else {
                ReadBook.readAloud(!BaseReadAloudService.pause)
            }
        }
        observeEvent<ArrayList<Int>>(EventBus.UP_CONFIG) { values ->
            if (5 in values && isInitFinish) {
                binding.readView.updateScrollReadPosition(preserveText = true)
            }
            values.forEach { value ->
                when (value) {
                    0 -> upSystemUiVisibility()
                    1 -> readView.upBg()
                    2 -> {
                        readView.upStyle()
                        upBookmarkIndicator()
                    }
                    3 -> readView.upBgAlpha()
                    4 -> readView.upPageSlopSquare()
                    5 -> if (isInitFinish) {
                        ReadBook.loadContent(
                            resetPageOffset = ReadBook.isScroll,
                            readPositionVersion = readView.getReadPositionVersion(),
                        )
                    }
                    6 -> readView.upContent(resetPageOffset = false)
                    8 -> ChapterProvider.upStyle()
                    9 -> readView.invalidateTextPage()
                    10 -> ChapterProvider.upLayout()
                    11 -> readView.submitRenderTask()
                    12 -> readView.upPageTouchClick()
                    13 -> upPageAnim()
                }
            }
            updateReadAloudFloatBar()
        }
        observeEvent<Int>(EventBus.ALOUD_STATE) {
            if (it == Status.STOP || it == Status.PAUSE) {
                ReadBook.curTextChapter?.let { textChapter ->
                    val page = textChapter.getPageByReadPos(ReadBook.durChapterPos)
                    if (page != null) {
                        page.removePageAloudSpan()
                        readView.upContent(resetPageOffset = false)
                    }
                }
            }
            updateReadAloudFloatBar()
        }
        observeEvent<Boolean>(EventBus.READ_ALOUD_FOLLOW) {
            updateReadAloudFloatBar()
        }
        observeEventSticky<Int>(EventBus.TTS_PROGRESS) { chapterStart ->
            lastReadAloudChapterStart = chapterStart
            lastReadAloudChapterIndex = ReadAloud.readAloudChapterIndex
            if (!ReadAloud.followReadAloudPosition) {
                scheduleAloudFollowCheck()
                return@observeEventSticky
            }
            lifecycleScope.launch(Main.immediate) {
                if (BaseReadAloudService.shouldApplySpeechProgressToVisibleReader(
                        isSpeechPlaying = BaseReadAloudService.isPlay()
                    )
                ) {
                    ReadBook.curTextChapter?.let { textChapter ->
                        ReadBook.durChapterPos = chapterStart
                        val pageIndex = ReadBook.durPageIndex
                        val aloudSpanStart = chapterStart - textChapter.getReadLength(pageIndex)
                        val page = textChapter.getPage(pageIndex)
                        page?.upPageAloudSpan(aloudSpanStart)
                        if (readView.isTouching && readView.curPage.textPage === page) {
                            // Same-page speech ranges must not cancel the user's pending swipe.
                            readView.curPage.invalidateContentView()
                            readView.submitRenderTask()
                        } else {
                            upContent()
                        }
                    }
                }
            }
        }
        observeEvent<Boolean>(PreferKey.keepLight) {
            upScreenTimeOut()
        }
        observeEvent<Boolean>(PreferKey.textSelectAble) {
            readView.curPage.upSelectAble(it)
        }
        observeEvent<String>(PreferKey.showBrightnessView) {
            readMenu.upBrightnessState()
        }
        observeEvent<List<SearchResult>>(EventBus.SEARCH_RESULT) {
            viewModel.searchResultList = it
        }
        observeEvent<Boolean>(EventBus.UPDATE_READ_ACTION_BAR) {
            readMenu.reset()
        }
        observeEvent<Boolean>(EventBus.UP_SEEK_BAR) {
            readMenu.upSeekBar()
        }
        observeEvent<Boolean>(EventBus.REFRESH_BOOK_CONTENT) { //书源js函数触发刷新
            if (lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) {
                refreshDurChapter()
            }
        }
        observeEvent<Boolean>(EventBus.REFRESH_BOOK_TOC) { //书源js函数触发刷新
            if (lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) {
                ReadBook.book?.let {
                    loadChapterList(it)
                }
            }
        }
    }

    private fun upScreenTimeOut() {
        val keepLightPrefer = getPrefString(PreferKey.keepLight)?.toInt() ?: 0
        screenTimeOut = keepLightPrefer * 1000L
        screenOffTimerStart()
    }

    /**
     * 重置黑屏时间
     */
    override fun screenOffTimerStart() {
        handler.post {
            if (screenTimeOut < 0) {
                keepScreenOn(true)
                return@post
            }
            val t = screenTimeOut - sysScreenOffTime
            if (t > 0) {
                keepScreenOn(true)
                handler.removeCallbacks(screenOffRunnable)
                handler.postDelayed(screenOffRunnable, screenTimeOut)
            } else {
                keepScreenOn(false)
            }
        }
    }

    companion object {
        private const val REVIEW_DIALOG_REQUEST_COOLDOWN_MS = 1500L
        const val RESULT_DELETED = 100
        private const val ACTION_READER_ITEM_PREFIX = "readerItem:"
        private const val ACTION_READER_MORE = "readerMore"
        private const val ACTION_READER_CONFIG = "readerConfig"
        private const val ACTION_HIGHLIGHT_STYLE = "highlightStyle"
        private const val ACTION_HIGHLIGHT_NOTE = "highlightNote"
        private const val ACTION_HIGHLIGHT_CREATE_RULE = "highlightCreateRule"
        private const val ACTION_HIGHLIGHT_COPY = "highlightCopy"
        private const val ACTION_HIGHLIGHT_DELETE = "highlightDelete"
        private const val ACTION_HIGHLIGHT_RULE_EDIT = "highlightRuleEdit"
        private const val ACTION_HIGHLIGHT_RULE_MANAGE = "highlightRuleManage"
        private const val ACTION_HIGHLIGHT_RULE_DISABLE = "highlightRuleDisable"
        private const val STATE_EDITING_HIGHLIGHT = "editingHighlight"
    }

}

internal fun visibleHighlightStyle(style: HighlightStyle?): HighlightStyle {
    return style?.takeUnless { it.isEmpty } ?: HighlightStyles.presets.first()
}

/**
 * 文字选择光标的位置换算
 * 光标视图在选区外侧和下方留有内边距以扩大触摸范围, 图标尖端仍对齐选区边界
 */
internal object SelectCursorGeometry {

    /** 开始光标图标的右上角对齐选区起点 */
    fun startCursorX(anchorX: Float, viewWidth: Int, paddingRight: Int): Float =
        anchorX - viewWidth + paddingRight

    /** 结束光标图标的左上角对齐选区终点 */
    fun endCursorX(anchorX: Float, paddingLeft: Int): Float = anchorX - paddingLeft

    fun cursorY(anchorY: Float, paddingTop: Int): Float = anchorY - paddingTop

    /**
     * 按下点到图标中心的偏移, 拖动时加上该偏移,
     * 按在图标外的触摸范围内也等同于按住图标中心, 选区不会跳动
     */
    fun touchOffset(touch: Float, leadingPadding: Int, iconSize: Int): Float =
        leadingPadding + iconSize / 2f - touch
}
