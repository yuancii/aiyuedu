﻿EPUB 双排版交付包

目标目录：E:\Code file\legado
源码基线：9b0bf8787293ee3482a4f9a2075325f3dabd0e60

changes.patch：本次全部源码修改，包括新增文件。
source-changes/：修改后的文件全文，供检查；不要直接覆盖已有本地修改。
app-app-debug.apk：已构建的调试包。
manifest.json：文件列表、SHA-256 和验证范围。

在本机 PowerShell 中，先将当前目录切换到本交付包解压目录，再执行：
$target = 'E:\Code file\legado'
$patch = (Resolve-Path '.\changes.patch').Path
git -C $target status --short
git -C $target apply --check $patch
if ($LASTEXITCODE -ne 0) { throw '源码检查失败，请停止并保留现有修改' }
git -C $target apply $patch
if ($LASTEXITCODE -ne 0) { throw '应用补丁失败，请停止' }
$apkDir = Join-Path $target 'artifacts'
New-Item -ItemType Directory -Path $apkDir -Force | Out-Null
$apkTarget = Join-Path $apkDir 'legado-epub-debug-d9c407079eae.apk'
if (Test-Path $apkTarget) { throw '目标 APK 已存在，请先核对哈希，勿覆盖' }
Copy-Item '.\app-app-debug.apk' $apkTarget
Get-FileHash $apkTarget -Algorithm SHA256

本次未包含 Agent 规则、本机配置或凭据。未替你修改本机文件。
原排版首版为连续滚动；高亮、笔记、朗读使用原有阅读器排版。
调试构建验证临时停用了 Firebase 配置生成，未进行真机验证。
