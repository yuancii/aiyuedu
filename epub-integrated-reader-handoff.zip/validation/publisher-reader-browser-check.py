from pathlib import Path
from playwright.sync_api import sync_playwright

script = Path('/workspace/aiyuedu/app/src/main/assets/epub/publisher-reader.js').read_text()
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 420, 'height': 640})
    failures = []
    page.on('pageerror', lambda e: failures.append(str(e)))
    page.set_content('''<html><head>
    <meta http-equiv="Content-Security-Policy" content="script-src 'none'; style-src 'unsafe-inline'">
    <style>body{margin:16px}p{font-size:18px!important;line-height:1.5;color:rgb(20,40,60)!important}.gap{height:800px}</style>
    </head><body><h1 id="first">第一章</h1><p id="a">前文 <b>跨节点</b>选文😀 结束。</p>
    <div class="gap"></div><h2 id="second">第二章</h2><p id="b">重复文字。</p>
    <div class="gap"></div><p id="c">前缀 重复文字。 后缀</p></body></html>''')
    page.evaluate(script)
    page.evaluate("window.legadoPublisherAnchors=[{id:'second',index:2},{id:'first',index:1}]")
    # Select a range spanning inline markup, including UTF-16 surrogate pairs.
    selection = page.evaluate('''() => {
      const p=document.querySelector('#a'), range=document.createRange();
      range.setStart(p.querySelector('b').firstChild,0); range.setEnd(p.lastChild,6);
      getSelection().removeAllRanges();getSelection().addRange(range);
      return legadoPublisher.selection();
    }''')
    assert selection['quote'] == '跨节点选文😀 结', selection
    assert selection['chapter'] == 1, selection
    page.evaluate('legadoPublisher.clearSelection()')
    # Duplicate quotes must use surrounding context rather than highlighting the first occurrence.
    page.evaluate('''legadoPublisher.annotations([{id:'h:1',quote:'重复文字。',fraction:0,
      prefix:'前缀 ',suffix:' 后缀',paint:{fill:'rgba(255,220,0,0.4)',bold:true,textColor:'rgb(200,0,0)'}}])''')
    assert page.locator('#b [data-legado-ink]').count() == 0
    assert page.locator('#c [data-legado-ink]').count() == 1
    page.wait_for_function("() => getComputedStyle(document.querySelector('#c [data-legado-ink]')).fontWeight === '700'")
    page.locator('#c [data-legado-ink]').click()
    assert page.evaluate('legadoPublisher.event().id') == 'h:1'
    # Typography preferences override even inline/stylesheet important declarations.
    config = dict(textSize=30, letterSpacing=.2, textBold=1, lineSpacingExtra=16,
                  textColor='rgb(80, 90, 100)', paragraphSpacing=20, paragraphIndent=2,
                  padding=[10,20,30,40], titleMode=1)
    page.evaluate('(c)=>legadoPublisher.applyStyle(c,["textSize","letterSpacing","lineSpacingExtra","textColor","padding","paragraphSpacing","paragraphIndent","titleMode"])', config)
    page.wait_for_function('() => legadoPublisher.restored')
    computed = page.locator('#a').evaluate('(e)=>{const s=getComputedStyle(e);return [s.fontSize,s.color,s.letterSpacing,s.lineHeight]}')
    assert computed == ['27px','rgb(80, 90, 100)','5.4px','54px'], computed
    assert page.locator('#a b').evaluate('(e)=>getComputedStyle(e).fontSize') == '27px'
    assert page.locator('body').evaluate('(e)=>getComputedStyle(e).padding') == '10px 20px 30px 40px'
    # Reset restores publisher declarations and priorities; repeat updates must not accumulate scaling.
    page.evaluate('(c)=>legadoPublisher.applyStyle(c,["textSize"])', config)
    page.wait_for_function('() => legadoPublisher.restored')
    assert page.locator('#a').evaluate('(e)=>getComputedStyle(e).fontSize') == '27px'
    page.evaluate('(c)=>legadoPublisher.applyStyle(c,[])', config)
    page.wait_for_function('() => legadoPublisher.restored')
    assert page.locator('#a').evaluate('(e)=>getComputedStyle(e).fontSize') == '18px'
    assert page.locator('#a').evaluate('(e)=>getComputedStyle(e).color') == 'rgb(20, 40, 60)'
    # Heading controls operate independently of the publisher's body typography.
    config.update(titleSize=8, titleBold=2, titleColor='rgb(30, 40, 50)', titleLineSpacingExtra=10, titleSpacing=[12,16])
    page.evaluate('(c)=>legadoPublisher.applyStyle(c,["titleSize","titleBold","titleColor","titleLineSpacingExtra","titleSpacing"])', config)
    page.wait_for_function('() => legadoPublisher.restored')
    assert page.locator('#first').evaluate('(e)=>getComputedStyle(e).fontSize') == '38px'
    assert page.locator('#first').evaluate('(e)=>getComputedStyle(e).fontWeight') == '300'
    assert page.locator('#first').evaluate('(e)=>getComputedStyle(e).marginTop') == '12px'
    assert page.locator('#a').evaluate('(e)=>getComputedStyle(e).fontSize') == '18px'
    # Highlight glyph markup must preserve the text index and disappear on removal.
    before = page.locator('body').inner_text()
    page.evaluate('legadoPublisher.annotations([])')
    assert page.locator('[data-legado-ink]').count() == 0
    assert page.locator('body').inner_text() == before
    # Saved quote fallback survives reflow and reversed TOC anchor ordering.
    page.evaluate("document.querySelector('#second').scrollIntoView()")
    saved = page.evaluate('legadoPublisher.capture()')
    assert saved['chapter'] == 2, saved
    page.evaluate('scrollTo(0,0)')
    page.evaluate('(p)=>legadoPublisher.restore(p,"")', saved)
    page.wait_for_function('() => legadoPublisher.restored')
    assert page.evaluate('legadoPublisher.capture().chapter') == 2
    assert not failures, failures
    browser.close()
    print('PASS: CSP, selection, shared chapter anchors, duplicate annotation context, typography overrides, publisher style reset, annotation removal and reading position restoration')
