﻿EPUB 阅读界面整合版

入口：打开 EPUB → 点击正文中间 → 界面 → 面板顶部选择“书籍原排版／阅读器排版”。
原排版和阅读器排版共用主阅读页、设置、字典、书签和高亮记录。

changes.patch：从原仓库基线 9b0bf8787293ee3482a4f9a2075325f3dabd0e60 应用全部修改。
update-from-first-debug.patch：已同步第一版 EPUB 源码（0b01183e29c28e1c76ed6b86c1feff7904bb9cee）时使用。
source-changes/：20 个相关源码文件的当前全文，用于审阅。不要直接覆盖已有本地修改。
app-app-debug.apk：最新版调试包，沿用之前的 Debug 签名。

在 Windows 解压此 ZIP，进入解压目录打开 PowerShell。
下面默认使用完整补丁；如果已同步第一版源码，把 changes.patch 换为 update-from-first-debug.patch。

$target = 'E:\Code file\legado'
$patch = (Resolve-Path '.\changes.patch').Path
git -C $target status --short
git -C $target apply --check $patch
if ($LASTEXITCODE -ne 0) { throw '检查失败：停止操作，保留本地修改，核对是否应使用上一版增量补丁' }
git -C $target apply $patch
if ($LASTEXITCODE -ne 0) { throw '应用补丁失败，请停止' }
$apkDir = Join-Path $target 'artifacts'
New-Item -ItemType Directory -Path $apkDir -Force | Out-Null
$apkTarget = Join-Path $apkDir 'legado-epub-integrated-debug-1133ae18fc89.apk'
if (Test-Path $apkTarget) { throw '目标 APK 已存在，请核对哈希，勿覆盖' }
Copy-Item '.\app-app-debug.apk' $apkTarget
Get-FileHash $apkTarget -Algorithm SHA256

APK SHA-256：1133ae18fc89869f1619262bb0e83aceb0824e5639d57e649458987aacaa1b2a

验证：18 项单元测试、Chromium 选文／高亮／字体与间距／定位检查通过，Debug APK 构建及签名校验通过。
尚未真机验证。本地验证临时跳过 Firebase 配置生成，未添加凭据或修改构建配置。
原排版当前以滚动阅读为主；原生仿真翻页动画未迁移到 WebView。
云端无法直接写入你的本地 E 盘，需要你执行以上步骤。
