package io.legado.app.ui.book.read.config;

import android.app.Application;
import android.content.Context;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import org.robolectric.RuntimeEnvironment;
import io.legado.app.R;
import io.legado.app.databinding.DialogReadBookStyleBinding;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 36, application = ReadStylePanelHostTest.PanelApplication.class)
public class ReadStylePanelHostTest {
    public static class PanelApplication extends Application {
        @Override public void onCreate() {
            super.onCreate();
            splitties.init.AppCtxKt.injectAsAppCtx(this);
        }
    }
    @Test public void actualReaderPanelInflatesInBothAppThemesAndSwitchesModes() {
        Context app = RuntimeEnvironment.getApplication();
        for (int theme : new int[]{R.style.AppTheme_Light, R.style.AppTheme_Dark}) {
            Context context = new ContextThemeWrapper(app, theme);
            DialogReadBookStyleBinding binding = DialogReadBookStyleBinding.inflate(LayoutInflater.from(context), new FrameLayout(context), false);
            binding.epubLayoutModes.check(R.id.epub_reader_mode);
            assertTrue(binding.epubReaderMode.isChecked());
            assertFalse(binding.epubPublisherMode.isChecked());
            binding.epubPublisherMode.performClick();
            assertTrue(binding.epubPublisherMode.isChecked());
            assertFalse(binding.epubReaderMode.isChecked());
            binding.epubReaderMode.performClick();
            assertTrue(binding.epubReaderMode.isChecked());
            assertFalse(binding.epubPublisherMode.isChecked());
        }
    }
    @Test public void previousMaterialControlRequiresAThemeTheAppDoesNotUse() {
        Context app = RuntimeEnvironment.getApplication();
        for (int theme : new int[]{R.style.AppTheme_Light, R.style.AppTheme_Dark}) {
            Context context = new ContextThemeWrapper(app, theme);
            try {
                new com.google.android.material.button.MaterialButton(context);
                fail("The negative control must reproduce the original theme mismatch");
            } catch (IllegalArgumentException expected) {
                assertTrue(expected.getMessage(), expected.getMessage().contains("Theme.MaterialComponents"));
            }
        }
    }
}
