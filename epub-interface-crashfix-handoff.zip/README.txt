﻿「界面」崩溃修复 · iQOO 11 arm64 调试包

安装文件：legado-interface-fixed-arm64-debug.apk
入口：EPUB 正文 → 点击中间 → 界面 → 顶部排版切换。

修复：将 Material 排版切换控件替换为项目已有的 AppCompat 主题控件；亮色、暗色面板加载均通过 Android 16 主机验证。

体积：约 55.1 MiB → 29.1 MiB；DEX 34 → 5；仅 arm64。
此包保留 Debug 属性；R8 在 Debug 模式下不进行代码优化或名称混淆，仅精简未使用代码和资源。
应用 ID、版本号范围和签名与上一版云端包兼容，可覆盖安装；不要卸载或清除数据。
安装耗时尚未在你的手机上实测，不能保证十几分钟的安装问题仅由体积导致。

源码同步：目标 E:\Code file\legado。解压后进入此目录的 PowerShell，选择适合本地源码状态的补丁：
- 已同步上一版整合版 314f64b：update-from-integrated-debug.patch
- 仅同步第一版 0b01183：update-from-first-debug.patch
- 原仓库基线 9b0bf87：changes.patch

$target = 'E:\Code file\legado'
$patch = (Resolve-Path '.\update-from-integrated-debug.patch').Path
git -C $target status --short
git -C $target apply --check $patch
if ($LASTEXITCODE -ne 0) { throw '补丁检查失败：请停止，保留本地修改并核对补丁版本' }
git -C $target apply $patch
if ($LASTEXITCODE -ne 0) { throw '应用补丁失败，请停止' }
$apkDir = Join-Path $target 'artifacts'
New-Item -ItemType Directory -Path $apkDir -Force | Out-Null
$apkTarget = Join-Path $apkDir 'legado-interface-fixed-arm64-debug-542929909238.apk'
if (Test-Path $apkTarget) { throw '目标文件已存在，请核对哈希，勿覆盖' }
Copy-Item '.\legado-interface-fixed-arm64-debug.apk' $apkTarget
Get-FileHash $apkTarget -Algorithm SHA256

本地构建：在 Android Studio 项目目录运行 .\gradlew.bat :app:assembleAppDebug -PcompactDebug=true -PtargetAbi=arm64-v8a
本地 Firebase 配置按原项目要求提供；云端验证仅通过临时 Gradle 初始化脚本跳过配置生成，未加入凭据。

验证：20 项测试通过；新增设备端面板回归用例已编译。尚未在真机运行或测量安装速度。
APK SHA-256：542929909238dea8f75c0fa41ce316c9f79be7c24dc434d280b1ca3ffbd56672
